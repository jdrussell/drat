


library(tidyverse)

x <-
  purrr::map(1:30, ~rnorm(5000)) %>%
  purrr::set_names(paste0("name_", 1:length(.)))

microbenchmark::microbenchmark({
  y <- do.call(rbind, x)
}, unit = "us")

microbenchmark::microbenchmark({
  y2 <- dplyr::bind_rows(x)
}, unit = "us")

microbenchmark::microbenchmark({
  y2a <- dplyr::bind_cols(x)
}, unit = "us")

microbenchmark::microbenchmark({
  y3 <- matrix(0, nrow = length(x), ncol = length(x[[1]]))
  for (i in seq_along(x)) {
    y3[i, ] <- x[[i]]
  }
}, unit = "us")

microbenchmark::microbenchmark({
  y4 <- matrix(unlist(x, use.names = FALSE), nrow = length(x), byrow = TRUE)
}, unit = "us")







library(matrixStats)

microbenchmark::microbenchmark({
  z <- apply(y, 1, median)
})
microbenchmark::microbenchmark({
  z1 <- matrixStats::rowMedians(y)
})


