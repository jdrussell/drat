
#' List of Global Constants
#'
#' @return list with various constants used in package functions
globalConstants <- function() {

  list(
    currentYear = 2017,
    useCreditSpreadForAnnuities = TRUE,
    minTargetProb = 0.05, #Dependent on number of sims?
    maxTargetProb = 0.95, #Dependent on number of sims?
    stdPctiles = seq.int(1, 19) / 20
  )
}
