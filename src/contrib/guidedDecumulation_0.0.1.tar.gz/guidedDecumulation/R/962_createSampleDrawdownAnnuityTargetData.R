

createSampleDrawdownAnnuityTargetData_1 <- function() {

  list(
    targetTerm = 20,
    annuityIncomePpnPreTarget = 1,
    annuityFloorPpnPreTarget = 0.8,
    targetIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      )
  )
}


createSampleDrawdownAnnuityTargetData_2 <- function() {

  list(
    targetTerm = 20,
    annuityIncomePpnPreTarget = 1,
    annuityFloorPpnPreTarget = 0.8,
    targetIncreaseData =
      list(
        increaseType = "none",
        increaseRate = "NA"
      )
  )
}
