

createSampleAssessSpendingTargetResidualData_1 <- function() {

  sampleEssVersionData <- "testData"
  sampleLongevityVersionData <- "baseTable.RDS"

  list(
    essVersionData = sampleEssVersionData,
    longevityVersionData = sampleLongevityVersionData,
    memberData = createSampleDrawdownMemberData_1(),
    potData = createSamplePotData_1(),
    drawdownIncomeData = createSampleDrawdownIncomeData_1(),
    residualAmountTargetData = createSampleDrawdownResidualTargetData_1(),
    outputData = createSampleDrawdownOutputData()
  )
}

createSampleGuideSpendingTargetResidualData_2 <- function() {

  sampleEssVersionData <- "testData"
  sampleLongevityVersionData <- "baseTable.RDS"

  list(
    essVersionData = sampleEssVersionData,
    longevityVersionData = sampleLongevityVersionData,
    memberData = createSampleDrawdownMemberData_1(),
    potData = createSamplePotData_2(),
    drawdownIncomeData = createSampleDrawdownIncomeData_2(),
    residualAmountTargetData = createSampleDrawdownResidualTargetData_2(),
    residualAmountGuidanceData = createSampleDrawdownGuidanceData(),
    outputData = createSampleDrawdownOutputData()
  )
}

