

#' Calculate Common Inputs for Drawdown Projections
#'
#' The purpose of this function is to calculate and group the input data for
#' drawdown projections.  Although variableIncome is included, this will be
#' simply overwritten in any optimisation routine.
#'
#' @param memberData list of member data inputs
#' @param potData list of inputs associated with pot data
#' @param drawdownIncomeData list of drawdown inputs
#' @param targetData target data (if NULL then use variable income increase
#'   data where appropriate)
#' @param essData data from ESS
#' @param projIndices the indices of inputs to use for projecting
#'
#' @return list of input data that won't vary in any optimisation (returns,
#'   platform fees, static income, elements required for flex amounts)
calculateCommonDrawdownInputs <- function(memberData, potData,
                                          drawdownIncomeData,
                                          targetData = NULL, essData,
                                          projIndices) {

  #calculate strategy returns
  strategyRtns <-
    calculateStrategyReturns(potData$potStrategy, essData, projIndices)

  #calculate platform fees
  platformFees <-
    calculatePlatformFees(potData$platformFees, essData, projIndices)

  #calculate static income
  staticIncome <-
    calculateDrawdownStaticIncome(drawdownIncomeData, essData, projIndices)

  #calculate variable income
  variableIncome <-
    calculateDrawdownVariableIncome(drawdownIncomeData, essData, projIndices)

  #calculate flex amounts and associated return metrics
  incomeFlexAmounts <-
    calculateDrawdownAnnualFlexAmounts(drawdownIncomeData, essData, projIndices)

  #Use variable increase data for flex adjustments if targetIncreaseData not
  #provided
  relRtnIncreaseData <-
    if (is.null(targetData$targetIncreaseData)) {
      drawdownIncomeData$variableIncomeIncreaseData
    } else {
      targetData$targetIncreaseData
    }
  relativeRtnMetrics <-
    calculateAnnualFlexRtnMetrics(strategyRtns, drawdownIncomeData,
      relRtnIncreaseData, essData, projIndices)

  targetResidualAmounts <-
    if (targetData$targetRef == "residualTarget") {
      calculateDrawdownResidualTargetAmounts(targetData, essData, projIndices)
    } else {
      NULL
    }

  list(
    initialPot = potData$potSizePounds,
    strategyRtns = strategyRtns,
    platformFees = platformFees,
    targetAmounts = targetResidualAmounts,
    incomeInputs =
      list(
        staticIncome = staticIncome,
        variableIncome = variableIncome,
        #Use variable income delta for guided, so set to 1 here
        variableIncomeDelta = 1,
        flexData = list(
          flexAmounts = incomeFlexAmounts,
          relativeRtnMetrics = relativeRtnMetrics
        )
      )
  )
}
