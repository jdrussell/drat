


createSampleDrawdownResidualTargetData_1 <- function() {

  list(
    targetTerm = 15,
    residualAmount = 200000,
    residualFloor = 150000,
    targetIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      )
  )

}

createSampleDrawdownResidualTargetData_2 <- function() {

  list(
    targetTerm = 15,
    residualAmount = 0,
    residualFloor = 0,
    targetIncreaseData =
      list(
        increaseType = "none",
        increaseRate = "NA"
      )
  )

}
