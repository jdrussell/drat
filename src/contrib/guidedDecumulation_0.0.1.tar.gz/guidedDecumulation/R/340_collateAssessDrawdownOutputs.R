

#' Collate Assess Drawdown Outputs
#'
#' @param potProjectionOutput
#' @param assessProbs
#' @param outputData
#' @param annuityPrices
#' @param survivalProbs
#' @param apiOutput
#'
#' @return list of outputs from assess drawdown
collateAssessDrawdownOutputs <- function(potProjectionOutput, assessProbs,
                                          outputData, annuityPrices,
                                          survivalProbs, apiOutput = TRUE) {

  assetsOut <-
    if (outputData$assetsAsReal) {
      transformToReal(potProjectionOutput$assets, essData)
    } else {
      potProjectionOutput$assets
    }
  incomePaid <-
    if (outputData$incomePaidAsReal) {
      transformToReal(potProjectionOutput$receivedIncome, essData)
    } else {
      potProjectionOutput$receivedIncome
    }

  assetQuantiles <-
    calcQuantiles(assetsOut,
      probs = outputData$summaryQuantiles)

  incomePaidQuantiles <-
    calcQuantiles(incomePaid,
      probs = outputData$summaryQuantiles)

  #validate outputs??

  if (apiOutput == TRUE) {

    outputList <-
      list(
        assessProbs = assessProbs,
        assetQuantiles = assetQuantiles,
        incomePaidQuantiles = incomePaidQuantiles
      )
    return(outputList)
  } else {
    #add more outputs here, e.g. for plotting outputs?
    outputList <-
      list(
        assessProbs = assessProbs,
        assetsOut = assetsOut,
        incomePaid = incomePaid,
        annuityPrices = annuityPrices,
        survivalProbs = survivalProbs$survivalProbs
      )
    return(outputList)
  }
}

