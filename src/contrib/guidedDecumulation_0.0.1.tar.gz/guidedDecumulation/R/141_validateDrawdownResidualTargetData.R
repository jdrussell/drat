

#' Validate Drawdown Target Residual Amount Inputs
#'
#' Helper function to check inputs associated with drawdown data for a target of
#' a residual amount
#'
#' @param residualTargetData list of inputs for targeting a residual amount
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated set of residual amount target inputs
validateDrawdownResidualTargetData <- function(residualTargetData, maxProj) {

  #The required content of the first level of drawdown data inputs
  validResidualTargetNames <-
    c(
      "targetTerm",
      "residualAmount",
      "residualFloor",
      "targetIncreaseData"
    )

    #Basic check that structure of first level of inputs is correct
    assertthat::assert_that(
      is.list(residualTargetData),
      all(names(residualTargetData) %in% validResidualTargetNames),
      all(validResidualTargetNames %in% names(residualTargetData))
    )

    #Check term, amount and floor
    assertthat::assert_that(
      is.numeric(residualTargetData$targetTerm),
      residualTargetData$targetTerm > 0,
      residualTargetData$targetTerm <=  maxProj,
      is.numeric(residualTargetData$residualAmount),
      length(residualTargetData$residualAmount) == 1,
      residualTargetData$residualAmount >= 0,
      is.numeric(residualTargetData$residualFloor),
      length(residualTargetData$residualFloor) == 1,
      residualTargetData$residualFloor >= 0,
      residualTargetData$residualFloor <= residualTargetData$residualAmount
    )

    #validate increase data
    residualTargetData$targetIncreaseData <-
      validateIncreaseData(residualTargetData$targetIncreaseData, maxProj)

    #Add a reference to the target date
    residualTargetData$targetRef <- "residualTarget"

    return(residualTargetData)

}
