

#' Calculate Quantiles
#'
#' @param data either vector or matrix of data to summarise
#' @param probs percentiles to calculate
#'
#' @return a data frame with columns for probs
calcQuantiles <- function(data, probs = globalConstants()$stdPctiles) {

  stopifnot(is.vector(data) || is.matrix(data))

  if (is.vector(data)) {
    dplyr::as_data_frame(
      t(quantile(data, probs = probs))
    )
  } else if (is.matrix(data)) {
    dplyr::as_data_frame(
      t(
        apply(data, 1, quantile, probs = probs)
      )
    )
  }
}
