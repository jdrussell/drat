

#' Calculate Weighted Probability for Drawdown Residual Target
#'
#' @param potProjectionOutput
#' @param residualTargetData
#' @param residualAmounts
#' @param annuityPrices matrix of annuity prices over projection period
#' @param survivalProbs
#'
#' @return a probability
calcDrawdownWtdProbResidualTarget <- function(potProjectionOutput,
                                              residualTargetData,
                                              residualAmounts, annuityPrices,
                                              survivalProbs) {

  assets <- potProjectionOutput$assets
  targetAssets <- residualAmounts$residualTarget
  targetFloorAssets <- residualAmounts$residualFloor

  successProbs <-
    if (residualTargetData$residualAmount == residualTargetData$residualFloor) {
      assets > targetAssets
    } else {
      pmax(
        pmin(
          (assets - targetFloorAssets) /
            (targetAssets - targetFloorAssets),
          1
        ),
        0
      )
    }

  deathAndSurvivalProbs <-
    c(survivalProbs$deathAtAge[2:nrow(assets) - 1],
      survivalProbs$survivalProbs[nrow(assets)])

  sum(deathAndSurvivalProbs * rowMeans(successProbs))

}
