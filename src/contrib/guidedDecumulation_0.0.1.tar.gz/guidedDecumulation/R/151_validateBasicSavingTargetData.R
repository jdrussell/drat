

#' Validate Basic Saving Target Inputs
#'
#' Helper function to check inputs associated with targets for basic saving
#' accounts
#'
#' @param savingTargetData list of inputs for targeting a residual amount
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated set of residual amount target inputs
validateBasicSavingTargetData <- function(savingTargetData, maxProj) {

  #The required content of the first level of drawdown data inputs
  validSavingTargetNames <-
    c(
      "targetTerm",
      "targetAmount",
      "targetFloor",
      "targetIncreaseData"
    )

    #Basic check that structure of first level of inputs is correct
    assertthat::assert_that(
      is.list(savingTargetData),
      all(names(savingTargetData) %in% validSavingTargetNames),
      all(validSavingTargetNames %in% names(savingTargetData))
    )

    #Check term, amount and floor
    assertthat::assert_that(
      is.numeric(savingTargetData$targetTerm),
      savingTargetData$targetTerm > 0,
      savingTargetData$targetTerm <=  maxProj,
      is.numeric(savingTargetData$targetAmount),
      savingTargetData$targetAmount >= 0,
      is.numeric(savingTargetData$targetFloor),
      savingTargetData$targetFloor >= 0,
      savingTargetData$targetFloor <= savingTargetData$targetAmount
    )

    #validate increase data
    savingTargetData$targetIncreaseData <-
      validateIncreaseData(savingTargetData$targetIncreaseData, maxProj)

    return(savingTargetData)

}
