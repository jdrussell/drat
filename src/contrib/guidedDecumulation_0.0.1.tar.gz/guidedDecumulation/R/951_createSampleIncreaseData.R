


createSampleIncreaseData_rpi <- function() {
  list(
    "increaseType" = "rpi",
    "increaseRate" = NA
  )
}

createSampleIncreaseData_salary <- function() {
  list(
    "increaseType" = "rpi",
    "increaseRate" = 0.01
  )
}

createSampleIncreaseData_fixed <- function() {
  list(
    "increaseType" = "fixed",
    "increaseRate" = 0.03
  )
}

createSampleIncreaseData_none <- function() {
  list(
    "increaseType" = "none",
    "increaseRate" = NA
  )
}
