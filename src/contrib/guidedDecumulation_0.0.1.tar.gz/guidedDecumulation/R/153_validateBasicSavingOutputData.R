

#' Validate Basic Saving Output Inputs
#'
#' Helper function to check inputs associated with how basic saving output is
#' summarised
#'
#' @param basicSavingOutputData list of output data inputs
#'
#' @return validated list of output data associated with basic saving accounts
validateBasicSavingOutputData <- function(basicSavingOutputData) {

  #The required content of the first level of drawdown data inputs
  validOutputInputNames <-
    c(
      "summaryQuantiles",
      "realOutput"
    )

  #Basic check that structure of first level is correct
  assertthat::assert_that(
    is.list(basicSavingOutputData),
    all(names(basicSavingOutputData) %in% validOutputInputNames),
    all(validOutputInputNames %in% names(basicSavingOutputData))
  )

  #Now check quantiles
  assertthat::assert_that(
    is.numeric(basicSavingOutputData$summaryQuantiles),
    sum(basicSavingOutputData$summaryQuantiles <
        globalConstants()$minTargetProb) == 0,
    sum(basicSavingOutputData$summaryQuantiles >
        globalConstants()$maxTargetProb) == 0
  )

    #And check realOutput
    assertthat::assert_that(
      is.logical(basicSavingOutputData$realOutput)
    )

    return(basicSavingOutputData)
}

