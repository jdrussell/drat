

#' Guided Decumulation API Entry
#'
#' @param inputJson a json of inputs
#'
#' @return a json of outputs
#' @export
#'
#' @examples
#' sampleInputsJson <-
#' jsonlite::toJSON(guidedDecumulation:::createSampleGuideSpendingTargetAnnuityData_2())
#' guidedOutputApiJson <- guidedDecumulationApi(sampleInputsJson)
guideSpendingAnnuityTargetApi <- function(inputJson) {

  #transform json to R list
  allInputs <- jsonlite::fromJSON(inputJson)

  #validate inputs
  validateGuidanceInputs(allInputs)

  essVersion <- allInputs$essVersionData
  mortalityVersion <- allInputs$mortalityVersionData
  memberData <- allInputs$memberData
  potData <- allInputs$potData
  drawdownData <- allInputs$drawdownData
  guidanceData <- allInputs$guidanceData

  #load ess data
  essData <- readEssDataFromPackage(essDetails = essVersion)

  #load mortality data
  qxData <- readQxDataFromPackage(mortalityVersion)

  solvedOutputs <-
    guidedDecumulation(memberData, potData, drawdownData, guidanceData,
      essData, qxData, apiOutput = TRUE)

  #transform output list to json
  jsonlite::toJSON(solvedOutputs)
}
