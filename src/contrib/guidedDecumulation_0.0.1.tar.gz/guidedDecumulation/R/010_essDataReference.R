
#' Summarise ESS Output Available
#'
#' Used in checking the names passed in as inputs for the strategy mapping
#'
#' @return list containing 3 elements: asset class returns, economic variables,
#'   and independent normals
essVariablesAvailable <- function() {

  essIndependentNormals <-
    c(
      "iidNormal_1"
    )

  list(
    assetClassReturnsNames = essAssetClassDataAvailable(),
    economicDataNames = essEconomicDataAvailable(),
    iidNormalsNames = essIndependentNormals
  )
}

#' List ESS Asset Classes Available
#'
#' @return list of ess return variables by name
essAssetClassDataAvailable <- function() {
  c(
    "ukEquity",
    "osEquity",
    "emEquity",
    "privateEquity",
    "property",
    "dgf",
    "medIlgs",
    "medFigs",
    "invGradeCorporates",
    "highYieldCredit",
    "overseasCredit",
    "cash"
  )
}

#' List ESS Economic Data Available
#'
#' @return list of ess economic variables by name
essEconomicDataAvailable <- function() {
  c(
    "rpiActualIndex",
    "giltsRealYield",
    "giltsNominalYield",
    "corpYield_AA",
    "corpSpread_AA"
  )
}
