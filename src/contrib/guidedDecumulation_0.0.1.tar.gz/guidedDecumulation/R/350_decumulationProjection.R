

#' Main Decumulation Function
#'
#'This is the main function for carrying out decumulation projections, used by
#'both assess and guide functions.
#'
#'The approach carried out will depend on some of the inputs.  For example, if
#'\code{targetData} is \code{NULL} then the projection will be carried out for
#'maximum possible period (either full length of the essData or up to the
#'maximum age available in the qx data.
#'
#' @param memberData
#' @param potData
#' @param drawdownIncomeData
#' @param targetData either \code{NULL} or the appropriate target details
#' @param outputData
#' @param guidedData if \code{NULL} then projection only assesses drawdown,
#'   otherwise should be guidance inputs
#' @param essData
#' @param qxData
#' @param apiOutput logical to allow for more granular outputs if function not
#'   being used via API call
#'
#' @return list of outputs, details of which depend on whether \code{apiOutput}
#'   is \code{TRUE} or \code{FALSE}
#' @export
decumulationProjection <- function(memberData, potData, drawdownIncomeData,
                                    targetData, outputData, guidedData = NULL,
                                    essData, qxData, apiOutput = TRUE) {

  #Calculate specific member Qx table
  memberQxTable <- calculateQxTable(memberData, qxData)

  #calculate survival probs
  survivalProbs <- calculateSurvivalProbs(memberQxTable)

  #calculate maxAge
  maxAge <-
    if (is.null(targetData)) {
      pmin(
        memberData$age + nrow(essData$assetClassReturns[[1]]) - 1,
        max(memberQxTable$Age)
      )
    } else {
      memberData$age + targetData$targetTerm
    }

  #calculate projIndices
  projIndices <- seq_len(maxAge - memberData$age + 1)

  #calculate targetIncreaseData (if targetData is null then use variableIncome
  #increase data)
  targetIncreaseData <-
    if (is.null(targetData)) {
      targetData$targetIncreaseData
    } else {
      drawdownIncomeData$variableIncomeIncreaseData
    }

  #calculate annuity prices
  annuityPrices <-
    calculateAnnuityPrices(maxAge, survivalProbs, targetIncreaseData, essData)

  #calculate common inputs
  commonDrawdownElements <-
    calculateCommonDrawdownInputs(memberData, potData,
      drawdownIncomeData, targetData, essData, projIndices)

  decumulationOutput <-
    if (is.null(guidedData)) {
      assessDrawdown(commonDrawdownElements, targetData, outputData,
        survivalProbs, annuityPrices, apiOutput)
    } else {
      guidedDrawdown(commonDrawdownElements, targetData, guidedData,
        outputData, survivalProbs, annuityPrices, apiOutput)
    }

  return(decumulationOutput)
}
