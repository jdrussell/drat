

#' Read ESS Data From Package
#'
#' At least for initial testing, we will store ess data as part of the package, 
#' specifically as an RDS to be read in as part of the api call.
#'
#' @param essDetails parameter used to reference specific calibrations
#'
#' @return list with 3 elements, a list of asset class returns, a list of
#'   economic variables, and the other a list of independent normals
#' @export
readEssDataFromPackage <- function(essDetails) {

  rdsLocation <-
    system.file("essDataCache", essDetails, "essData.RDS",
      package = "guidedDecumulation", mustWork = TRUE)

  readRDS(rdsLocation)
}

