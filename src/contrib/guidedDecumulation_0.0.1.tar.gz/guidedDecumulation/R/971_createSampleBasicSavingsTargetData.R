


createSampleBasicSavingsTargetData_1 <- function() {

  list(
    targetTerm = 15,
    targetAmount = 200000,
    targetFloor = 150000,
    targetIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      )
  )

}

createSampleBasicSavingsTargetData_2 <- function() {

  list(
    targetTerm = 15,
    targetAmount = 100000,
    targetFloor = 100000,
    targetIncreaseData =
      list(
        increaseType = "none",
        increaseRate = "NA"
      )
  )

}
