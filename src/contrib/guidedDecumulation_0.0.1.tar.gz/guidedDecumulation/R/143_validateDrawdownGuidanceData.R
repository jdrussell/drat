

#' Validate Drawdown Guidance Inputs
#'
#' Helper function to check guidance inputs associated with drawdown data
#'
#' @param drawdownGuidanceData list of guidance inputs
#'
#' @return validated guidence data inputs
validateDrawdownGuidanceInputs <- function(drawdownGuidanceData) {

  #The required content of the first level of drawdown data inputs
  validGuidanceInputNames <-
    c(
      "probTargets"
    )

    #Basic check that structure of first level is correct
    assertthat::assert_that(
      is.list(drawdownGuidanceData),
      all(names(drawdownGuidanceData) %in% validGuidanceInputNames),
      all(validGuidanceInputNames %in% names(drawdownGuidanceData))
    )

    #Now check increase types
    assertthat::assert_that(
      is.numeric(drawdownGuidanceData$probTargets),
      length(drawdownGuidanceData$probTargets) >= 1,
      length(drawdownGuidanceData$probTargets) <=
        drawdownConstants()$maxNumberOfProbTargets,
      sum(drawdownGuidanceData$probTargets <
          drawdownConstants()$minTargetProb) == 0,
      sum(drawdownGuidanceData$probTargets >
          drawdownConstants()$maxTargetProb) == 0
    )

    return(drawdownGuidanceData)
}

