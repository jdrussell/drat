

assessAccumulateSavingsApi <- function(inputJson) {

  #transform json to R list
  allInputs <- jsonlite::fromJSON(inputJson)

  essVersion <- validateEssVersion(allInputs$essVersionData)

  potData <- validatePotData(allInputs$potData)
  savingsData <- validateSavingsData(allInputs$savingsData)
  savingsOutputs <- validateSavingsOutputs(allInputs$savingsOutputs)

  #load ess data
  essData <- readEssDataFromPackage(essDetails = essVersion)

  assessOutputs <-
    assessAccumulateSavings(potData, savingsData, savingsOutputs, essData,
      apiOutput = TRUE)

  #transform output list to json
  jsonlite::toJSON(assessOutputs)
}

assessAccumulateSavings <- function(potData, savingsData, savingsOutputs,
                                    essData, apiOutput = TRUE) {

  commonInputs <-
    collateCommonSavingsInputs(potData, savingsData, essData)

  initialPot <- potData$potSizePounds
  cbnsPaid <- calculateSavingsCbns(savingsData, essData, commonInputs$nproj)

  projectedPot <-
    projectSavingsPot(initialPot, cbnsPaid, commonInputs$rtns,
      commonInputs$fees)

  assetsOut <-
    if (savingsOutputs$realTarget) {
      transformToReal(projectedPot$assets, essData)
    } else {
      projectedPot$assets
    }
  cbnsPaid <-
    if (savingsOutputs$realOutput) {
      transformToReal(projectedPot$cbnsPaid, essData)
    } else {
      projectedPot$cbnsPaid
    }

  potQuantiles <-
    calcQuantiles(assetsOut,
      probs = savingsOutputs$summaryQuantiles)

  cbnQuantiles <-
    calcQuantiles(cbnsPaid,
      probs = savingsOutputs$summaryQuantiles)

  if (apiOutput == TRUE) {
    outputList <-
      list(
        potQuantiles = potQuantiles,
        cbnQuantiles = cbnQuantiles
      )
    return(outputList)
  } else {
    outputList <-
      list(
        assetsOut = assetsOut,
        cbnsPaid = cbnsPaid,
        rpiIndex = essData$economicData$rpiActualIndex
      )
    return(outputList)
  }
}


guidedAccumulateSavings <- function(potData, savingsData, savingsGuidanceData,
                                    savingsOutputs, essData, apiOutput = TRUE) {

  commonInputs <-
    collateCommonSavingsInputs(potData, savingsData, essData)

  initialPot <- potData$potSizePounds

  baseCbnsPaid <-
    calculateSavingsCbns(savingsData, essData, commonInputs$nproj)

  baseProjectedPot <-
    projectSavingsPot(initialPot, baseCbnsPaid, commonInputs$rtns,
      commonInputs$fees)

  baseAssetsOut <-
    if (savingsGuidanceData$realTarget) {
      transformToReal(baseProjectedPot$assets, essData)
    } else {
      baseProjectedPot$assets
    }

  basePotAtTargetPercentile <-
    apply(baseAssetsOut, 1, quantile,
      probs = savingsGuidanceData$targetConfidence)

  solvedYearToTarget <-
    sum(basePotAtTargetPercentile <= savingsGuidanceData$targetAmount) - 1

  #Project pot and solve for year at which target reached for given confidence
  #level

  #Solve for monthly income such that target reached for given confidence level
  #at target date
  #Only calculate quantile on specific row


}

collateCommonSavingsInputs <- function(potData, savingsData, essData) {

  #Project for full length of ESS data available
  nproj <- nrow(essData$assetClassReturns[[1]]) - 1

  #calculate strategy returns and absolute fees
  strategyRtns <- calculateStrategyReturns(potData, essData, nproj)
  potPctFees <- potData$potFees$pctAssetValue
  absoluteFees <- calculateAbsoluteFees(potData, essData, nproj)

  list(
    nproj = nproj,
    rtns = strategyRtns,
    fees =
      list(
        potPctFees,
        absoluteFees
      )
  )
}

calculateSavingsCbns <- function(savingsData, essData, nproj) {

  cbnAmount <- savingsData$mthlyCbnPounds * 12

  cbnIncreases <- savingsData$cbnIncreaseData

  applyIncrease(cbnAmount, cbnIncreases, essData, nproj)
}

projectSavingsPot <- function(initialPot, cbnAmounts, returns, fees) {

  nproj <- dim(returns)[1] - 1

  initParams <-
    list(
      startYear = 0,
      outputList =
        list(
          assets = initialPot,
          cbnsPaid = 0
        )
    )

  stepFn <- function(stepParams) {

    startYear = stepParams$startYear
    projIndex <- startYear + 2
    startYrIndex <- startYear + 1

    #Extract specific projection vectors from matrices
    rtns <- returns[projIndex, ]

    #Need to work out bps fees based on pot size

    absoluteFees <- fees$absoluteFees[projIndex, ]
    cbn <- cbnAmounts[projIndex, ]

    #Pay fees first
    startAssets <- stepParams$outputList$assets - absoluteFees

    #Assume cbns paid halfway through year
    updatedAssets <- startAssets * (1 + rtns) + cbn * sqrt(1 + rtns)

    stepParams$startYear <- startYear + 1
    stepParams$outputList$assets <- updatedAssets
    stepParams$outputList$cbnsPaid <- cbn
    return(stepParams)
  }

  funcall <- function(params, f) f(params)

  allSimResults <-
    purrr::accumulate(
      rep.int(list(stepFn), nproj),
      funcall,
      .init = initParams
    )

  #Need to turn list of output lists into output list of lists
  transposedOutput <-
    purrr::transpose(
      purrr::map(
        allSimResults,
        "outputList"
      )
    )
  #And then create list of matrices
  #Drop is there in case single element output is included
  purrr::map(transposedOutput, ~ drop(do.call(rbind, .x)))
}

calculatePctAssetFees <- function(assetVector, fees) {


}

