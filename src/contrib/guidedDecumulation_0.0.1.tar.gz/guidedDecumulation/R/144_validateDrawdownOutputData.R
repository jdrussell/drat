

#' Validate Drawdown Output Inputs
#'
#' Helper function to check inputs associated with how drawdown output is
#' summarised
#'
#' @param drawdownOutputData list of output data inputs
#'
#' @return validated list of output data associated with drawdown
validateDrawdownOutputData <- function(drawdownOutputData) {

  #The required content of the first level of drawdown data inputs
  validOutputInputNames <-
    c(
      "summaryQuantiles",
      "incomePaidAsReal",
      "assetsAsReal"
    )

  #Basic check that structure of first level is correct
  assertthat::assert_that(
    is.list(drawdownOutputData),
    all(names(drawdownOutputData) %in% validOutputInputNames),
    all(validOutputInputNames %in% names(drawdownOutputData))
  )

  #Now check quantiles
  assertthat::assert_that(
    is.numeric(drawdownOutputData$summaryQuantiles),
    sum(drawdownOutputData$summaryQuantiles <
        globalConstants()$minTargetProb) == 0,
    sum(drawdownOutputData$summaryQuantiles >
        globalConstants()$maxTargetProb) == 0
  )

    #And check real output
    assertthat::assert_that(
      is.logical(drawdownOutputData$incomePaidAsReal),
      length(drawdownOutputData$incomePaidAsReal) == 1,
      is.logical(drawdownOutputData$assetsAsReal),
      length(drawdownOutputData$assetsAsReal) == 1
    )

    return(drawdownOutputData)
}

