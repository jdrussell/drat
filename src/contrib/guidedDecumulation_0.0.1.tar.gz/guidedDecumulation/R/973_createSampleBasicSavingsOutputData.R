

createSampleBasicSavingsOutputData <- function() {
  list(
    summaryQuantiles = globalConstants()$stdPctiles,
    realOutput = FALSE
  )
}
