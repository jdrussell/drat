

createSamplePlatformFees_1 <- function() {
  list(
    "ppnAssets" =
      list(
        "tierFloor" = 0,
        "tierFeePpn" = 0.01,
        "tierFloorIncrease" =
          list(
            "increaseType" = "none",
            "increaseRate" = NA
          ),
        "tierMethod" = "banded"
      ),
    "absoluteAmounts" =
      list(
        "feePounds" = 100,
        "feePoundsIncrease" =
          list(
            "increaseType" = "rpi",
            "increaseRate" = NA
          )
      )
  )
}

createSamplePlatformFees_2 <- function() {
  list(
    "ppnAssets" =
      list(
        "tierFloor" = c(0, 500000, 750000),
        "tierFeePpn" = c(0.01, 0.0075, 0.005),
        "tierFloorIncrease" =
          list(
            "increaseType" = "none",
            "increaseRate" = NA
          ),
        "tierMethod" = "banded"
      ),
    "absoluteAmounts" =
      list(
        "feePounds" = 100,
        "feePoundsIncrease" =
          list(
            "increaseType" = "rpi",
            "increaseRate" = NA
          )
      )
  )
}

createSamplePlatformFees_3 <- function() {
  list(
    "ppnAssets" =
      list(
        "tierFloor" = c(0, 500000, 750000),
        "tierFeePpn" = c(0.01, 0.0075, 0.005),
        "tierFloorIncrease" =
          list(
            "increaseType" = "none",
            "increaseRate" = NA
          ),
        "tierMethod" = "wholeFund"
      ),
    "absoluteAmounts" =
      list(
        "feePounds" = 100,
        "feePoundsIncrease" =
          list(
            "increaseType" = "rpi",
            "increaseRate" = NA
          )
      )
  )
}





