


createSampleBasicSavingCbnData_1 <- function() {

  list(
    staticCbns = 0,
    staticCbnIncreaseData =
      list(
        increaseType = "none",
        increaseRate = NA
      ),
    variableCbns = 500,
    variableCbnsIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      ),
    maxAnnualCbns = NA,
    maxCbnsIncreaseData =
      list(increaseType = "rpi",
        increaseRate = "NA"
      )
  )
}

createSampleBasicSavingCbnData_2 <- function() {

  list(
    staticCbns = c(0, 0, 0, 0, 10000, 0),
    staticCbnIncreaseData =
      list(
        increaseType = "none",
        increaseRate = NA
      ),
    variableCbns = 500,
    variableCbnsIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      ),
    maxAnnualCbns = 10000,
    maxCbnsIncreaseData =
      list(increaseType = "rpi",
        increaseRate = "NA"
      )
  )
}
