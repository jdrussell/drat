
#' Validate Pot Data Inputs
#'
#' @param potData list of inputs associated with pot data
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated potData inputs
validatePotDataInputs <- function(potData, maxProj) {

  #The required content of the first level of pot data inputs
  validPotDataNames <-
    c(
      "potSizePounds",
      "potStrategy",
      "platformFees"
    )

  #Basic check that structure of first level of inputs is correct
  assertthat::assert_that(
    is.list(potData),
    all(names(potData) %in% validPotDataNames),
    all(validPotDataNames %in% names(potData))
  )

  #Check pot size
  assertthat::assert_that(
    is.numeric(potData$potSizePounds),
    length(potData$potSizePounds) == 1,
    potData$potSizePounds > 0
  )

  potData$potStrategy <-
    validatePotStrategyInputs(potData$potStrategy, maxProj)

  potData$platformFees <- validatePlatformFees(potData$platformFees, maxProj)

  return(potData)
}


