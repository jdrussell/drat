

#' Apply Increase
#'
#' @param amount vector of amount to increase (could be a single number)
#' @param increaseDataInputs list with increase type and rate
#' @param essData data from ESS
#' @param stockOrFlow should increases be applied directly ("stock") or lagged
#'   one year ("flow")
#'
#' @return matrix of amounts adjusted by appropriate increases
applyIncrease <- function(amount, increaseDataInputs, essData,
                          stockOrFlow = c("flow", "stock")) {

  stockOrFlow <- match.arg(stockOrFlow)

  rpiIndex <- essData$economicData$rpiActualIndex

  adjRpiIndex <-
    switch(stockOrFlow,
      "stock" = rpiIndex,
      "flow" =
        rbind(
          rep.int(1, ncol(rpiIndex)),
          rpiIndex[1:(nrow(rpiIndex) - 1), , drop = FALSE]
        )
    )

  baseAmounts <-
    if (length(amount) == 1) {
      rep.int(amount, nrow(rpiIndex))
    } else {
      amount
    }

  increaseRate <-
    switch(stockOrFlow,
      "stock" = increaseDataInputs$increaseRate,
      "flow" = c(0, head(increaseDataInputs$increaseRate, -1))
    )
  increaseIndex <- cumprod(1 + increaseRate)

  #apply increases to amounts
  switch(increaseDataInputs$increaseType,
    none =
      diag(baseAmounts, nrow = length(baseAmounts)) %*%
      matrix(1, nrow = length(baseAmounts), ncol = ncol(adjRpiIndex)),
    rpi =
      applyVectorMatrixCalc(baseAmounts,
        diag(increaseIndex, nrow = nrow(adjRpiIndex)) %*% adjRpiIndex),
    fixed =
      diag(baseAmounts * increaseIndex, nrow = length(baseAmounts)) %*%
      matrix(1, nrow = length(baseAmounts), ncol = ncol(adjRpiIndex))
  )
}


#' Transform to Real (RPI) Amounts
#'
#' @param output data to be transformed, assume first
#' @param essData data from ESS
#' @param stockOrFlow should rpi deflator be applied directly ("stock") or
#'   lagged one year ("flow")
#'
#' @return transformed output
transformToReal <- function(output, essData, stockOrFlow = c("flow", "stock")) {

  stockOrFlow <- match.arg(stockOrFlow)

  rpiIndex <- essData$economicData$rpiActualIndex

  rpiDeflator <-
    switch(stockOrFlow,
      stock = 1 / rpiIndex,
      flow =
        rbind(
          rep.int(1, ncol(rpiIndex)),
          1 / rpiIndex[1:(nrow(rpiIndex) - 1), , drop = FALSE]
        )
    )

  if (is.vector(output)) {
    nrows <- length(output)
    diag(output, nrow = nrows) %*% rpiDeflator[1:nrows, , drop = FALSE]
  } else if (is.matrix(output)) {
    nrows <- nrow(output)
    if (ncol(output) == 1) {
      diag(as.vector(output), nrow = nrows) %*%
        rpiDeflator[1:nrows, , drop = FALSE]
    } else {
      output * rpiDeflator[1:nrows, , drop = FALSE]
    }
  }
}
