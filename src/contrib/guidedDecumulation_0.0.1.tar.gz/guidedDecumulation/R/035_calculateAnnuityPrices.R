


#' Calculate Annuity Prices
#'
#' @param maxAge age up to which to calculate annuity prices
#' @param survivalProbs dataframe of age and survival probabilities
#' @inheritParams applyIncrease
#'
#' @return a matrix of annuity prices, assuming payment in advance
calculateAnnuityPrices <- function(maxAge, survivalProbs, increaseDataInputs,
  essData) {

  #Only need economic data from ess
  economicData <- essData$economicData

  increaseType <- increaseDataInputs$increaseType
  increaseRate <- tail(increaseDataInputs$increaseRate, 1)

  matrixRows <-
    seq_along(dplyr::filter(survivalProbs, age <= maxAge)$age)

  probs <- head(survivalProbs$survivalProbs, -1)

  creditSpread <-
    if (globalConstants()$useCreditSpreadForAnnuities) {
      economicData$corpSpread_AA[matrixRows, , drop = FALSE]
    } else {
      0
    }

  annuityYields <-
    switch(increaseType,
      rpi =
        economicData$giltsRealYield[matrixRows, , drop = FALSE] + creditSpread,
      economicData$giltsNominalYield[matrixRows, , drop = FALSE] + creditSpread
    )

  #Calculate net yields if fixed increases
  annuityYields <-
    switch(increaseType,
      fixed = (1 + annuityYields) / (1 + increaseRate) - 1,
      annuityYields
    )

  #Assume payment occurs at start year
  payments <- c(1, rep.int(1, length(probs) - 1))

  annuityPrices <-
    do.call(
      rbind,
      purrr::map(matrixRows, function(i) {
        wtdPayments <-
          if (i == 1) {
            probs * payments
          } else {
            tail(payments, -i + 1) * tail(probs, -i + 1) / probs[i]
          }
        purrr::reduce(
          purrr::map(
            1:length(wtdPayments),
            ~ wtdPayments[.x] * ((1 + annuityYields[i, ]) ^ (-.x + 1))
          ), `+`)
      })
    )

 annuityPrices

}
