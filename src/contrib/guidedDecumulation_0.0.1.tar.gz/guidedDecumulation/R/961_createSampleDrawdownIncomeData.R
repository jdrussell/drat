


createSampleDrawdownIncomeData_1 <- function() {

  list(
    staticIncome = 0,
    staticIncomeIncreaseData =
      list(
        increaseType = "none",
        increaseRate = NA
      ),
    variableIncome = 5000,
    variableAnnualFlexUp = 0,
    variableAnnualFlexDown = 500,
    variableIncomeIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      )
  )

}

createSampleDrawdownIncomeData_2 <- function() {

  list(
    staticIncome = c(0, 0, 0, 0, 20000, 20000, 20000, 0),
    staticIncomeIncreaseData =
      list(
        increaseType = "none",
        increaseRate = NA
      ),
    variableIncome = 5000,
    variableAnnualFlexUp = 0,
    variableAnnualFlexDown = 500,
    variableIncomeIncreaseData =
      list(
        increaseType = "rpi",
        increaseRate = "NA"
      )
  )

}
