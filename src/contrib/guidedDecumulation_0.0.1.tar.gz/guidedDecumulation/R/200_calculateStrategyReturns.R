

#' Apply Strategy Mapping
#'
#' Given inputs for pot strategy, calculate strategy returns.
#'
#' @param potStrategy inputs for strategy (a list with elements:
#'   assetClassMapping, independentRiskFactorInputs and fees)
#' @inheritParams applyIncrease
#' @param projIndices the indices of inputs to use for projecting
#'
#' @return a return matrix
calculateStrategyReturns <- function(potStrategy, essData, projIndices) {

  #potStrategy is a list with elements: assetClassMapping,
  #independentRiskFactorInputs, and fees
  assetClassReturns <- essData$assetClassReturns
  iidNormals <- essData$iidNormals

  #matrix approach first
  baseRtnMatrix <-
    purrr::reduce(
      purrr::map2(
        names(potStrategy$assetClassMapping),
        potStrategy$assetClassMapping,
        ~applyVectorMatrixCalc(
          .y[projIndices],
          assetClassReturns[[.x]]
        )
      ),
      `+` #add all resulting matrices
    )

  #now calculate independent risk factor
  riskFactorInputs <- potStrategy$independentRiskFactorInputs

  muVector <- riskFactorInputs$mu[projIndices]
  sigmaVector <- riskFactorInputs$sigma[projIndices]

  #Adding vector to matrix using R's recycling approach
  riskFactorMatrix <-
    muVector +
    applyVectorMatrixCalc(sigmaVector, iidNormals$iidNormal_1)

  #Now allow for fund charges
  fundCharges <- potStrategy$fundCharges$fundFeesPpnAssets[projIndices]

  #And calculate tax adjustment
  taxRtnImpact <- potStrategy$taxTreatment$returnAdjustment[projIndices]

  rtnMatrixPostTax <-
    baseRtnMatrix + riskFactorMatrix - fundCharges + taxRtnImpact

  #Just make sure first row is zero
  rtnMatrixPostTax[1, ] <- 0

  return(rtnMatrixPostTax)
}


