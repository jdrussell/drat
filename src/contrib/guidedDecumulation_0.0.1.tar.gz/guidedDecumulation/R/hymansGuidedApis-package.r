#' guidedDecumulation
#'
#' This package provides access to functions for assessing and providing guided
#' outcomes for various accumulation and decumulation propositions
#'
#' @name guidedDecumulation
#' @docType package
NULL
