

createSamplePotStrategy_1 <- function() {
  list(
    "assetClassMapping" =
      list(
        "ukEquity" = 0.5,
        "cash" = 0.5
      ),
    "independentRiskFactorInputs" =
      list(
        "mu" = 0,
        "sigma" = 0
      ),
    "fundCharges" =
      list(
        "fundFeesPpnAssets" = 0.003
      ),
    "taxTreatment" =
      list(
        "returnAdjustment" = -0.005
      )
  )
}


createSamplePotStrategy_2 <- function() {
  list(
    "assetClassMapping" =
      list(
        "ukEquity" = c(0.5, 0.5, 0.5, 0.4, 0.4, 0.4, 0.3, 0.3, 0.3),
        "cash" = c(0.5, 0.5, 0.5, 0.6, 0.6, 0.6, 0.7, 0.7, 0.7)
      ),
    "independentRiskFactorInputs" =
      list(
        "mu" = 0,
        "sigma" = 0
      ),
    "fundCharges" =
      list(
        "fundFeesPpnAssets" = 0.003
      ),
    "taxTreatment" =
      list(
        "returnAdjustment" = rep.int(-0.005, 9)
      )
  )
}
