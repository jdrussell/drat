

#' Validate Basic Saving Guidance Inputs
#'
#' Helper function to check guidance inputs associated with basic saving data
#'
#' @param savingGuidanceData list of guidance inputs
#'
#' @return validated guidence data inputs
validateBasicSavingGuidanceData <- function(savingGuidanceData) {

  #The required content of the first level of drawdown data inputs
  validGuidanceInputNames <-
    c(
      "probTargets"
    )

    #Basic check that structure of first level is correct
    assertthat::assert_that(
      is.list(savingGuidanceData),
      all(names(savingGuidanceData) %in% validGuidanceInputNames),
      all(validGuidanceInputNames %in% names(savingGuidanceData))
    )

    #Now check increase types
    assertthat::assert_that(
      is.numeric(savingGuidanceData$probTargets),
      length(savingGuidanceData$probTargets) >= 1,
      length(savingGuidanceData$probTargets) <=
        globalConstants()$maxNumberOfProbTargets,
      sum(savingGuidanceData$probTargets <
          globalConstants()$minTargetProb) == 0,
      sum(savingGuidanceData$probTargets >
          globalConstants()$maxTargetProb) == 0
    )

    return(savingGuidanceData)
}

