

#' Validate Basic Saving Contribution Inputs
#'
#' Helper function to check inputs associated with contributions for basic
#' saving accounts
#'
#' @param basicCbnData list of drawdown income inputs
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated set of income data inputs
validateBasicSavingCbnData <- function(basicCbnData, maxProj) {

  #The required content of the first level of drawdown data inputs
  validBasicSavingCbnDataNames <-
    c(
      "staticCbns",
      "staticCbnIncreaseData",
      "variableCbns",
      "variableCbnsIncreaseData",
      "maxAnnualCbns",
      "maxCbnsIncreaseData"
    )

    #Basic check that structure of first level of inputs is correct
    assertthat::assert_that(
      is.list(basicCbnData),
      all(names(basicCbnData) %in% validBasicSavingCbnDataNames),
      all(validBasicSavingCbnDataNames %in% names(basicCbnData))
    )

    #Check static income
    assertthat::assert_that(
      is.numeric(basicCbnData$staticCbns),
      sum(basicCbnData$staticCbns < 0) == 0
    )

    #Extend static cbns and validate increase data
    basicCbnData$staticCbns <-
      extendInputsForProjectionPeriod(basicCbnData$staticCbns, maxProj)

    basicCbnData$staticCbnIncreaseData <-
      validateIncreaseData(basicCbnData$staticCbnIncreaseData, maxProj)

    #Now variable cbns
    assertthat::assert_that(
      is.numeric(basicCbnData$variableCbns),
      sum(basicCbnData$variableCbns < 0) == 0
    )

    #Extend variable cbn inputs
    basicCbnData$variableIncome <-
      extendInputsForProjectionPeriod(basicCbnData$variableIncome, maxProj)

    basicCbnData$variableCbnsIncreaseData <-
      validateIncreaseData(basicCbnData$variableCbnsIncreaseData, maxProj)

    #Extend max cbn inputs
    basicCbnData$maxAnnualCbns <-
      if (is.na(basicCbnData$maxAnnualCbns)) {
        extendInputsForProjectionPeriod(-1, maxProj)
      } else {
        extendInputsForProjectionPeriod(basicCbnData$maxAnnualCbns, maxProj)
      }

    basicCbnData$maxCbnsIncreaseData <-
      validateIncreaseData(basicCbnData$maxCbnsIncreaseData, maxProj)

    return(basicCbnData)
}
