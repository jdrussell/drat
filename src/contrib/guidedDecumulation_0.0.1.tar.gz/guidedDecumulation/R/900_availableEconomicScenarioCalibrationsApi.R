


#' List ESS Data Available
#'
#' Details the stored ess calibrations available to the API
#'
#' @return json with list of ess data versions available
#' @export
availableEconomicScenarioCalibrationsApi <- function() {
  x <-
    list.files(
      system.file("essDataCache", package = "guidedDecumulation",
        mustWork = TRUE)
    )
  jsonlite::toJSON(x)
}

