

#' Guided Drawdown
#'
#' @param commonDrawdownElements
#' @param targetData
#' @param guidedData
#' @param outputData
#' @param survivalProbs
#' @param annuityPrices
#' @param apiOutput
#'
#' @return
guidedDrawdown <- function(commonDrawdownElements, targetData, guidedData,
                            outputData, survivalProbs, annuityPrices,
                            apiOutput = TRUE) {

  solverFn <- function(variableDelta, targetProb) {

    initialPot <- commonDrawdownElements$initialPot
    returns <- commonDrawdownElements$strategyRtns
    platformFees <- commonDrawdownElements$platformFees
    incomeInputs <- commonDrawdownElements$incomeInputs

    incomeInputs$variableIncomeDelta <- variableDelta / 100

    potProjectionOutput <-
      projectDrawdownPot(initialPot, returns, platformFees, incomeInputs)

    assessProbabilities <-
      if (is.null(targetData)) {
        calcDrawdownProbPaymentOnly(potProjectionOutput, survivalProbs)
      } else {
        switch(
          targetData$targetRef,
          annuityTarget =
            calcDrawdownWtdProbAnnuityTarget(potProjectionOutput, targetData,
              annuityPrices, survivalProbs),
          residualTarget =
            calcDrawdownWtdProbResidualTarget(potProjectionOutput,
              targetData, commonDrawdownElements$targetAmounts, annuityPrices,
              survivalProbs)
        )
      }

    (assessProbabilities * 100 - targetProb * 100) ^ 2
  }

  guidanceSolutions <-
    purrr::map_dbl(
      guidedData$probTargets,
      ~ optimx::optimx(
        c(variableDelta = 100),
        solverFn,
        lower = 0,
        method = "bobyqa", #"L-BFGS-B",
        targetProb = .x#,
        #control = list(maxfun = 100)
      )$variableDelta[[1]])

  guidedAssessments <-
    purrr::map(
      guidanceSolutions,
      function(x) {
        commonDrawdownElements$incomeInputs$variableIncomeDelta <- x
        assessDrawdown(commonDrawdownElements, targetData, outputData,
          survivalProbs, annuityPrices, apiOutput)
      }
    )

  purrr::pmap(
    list(guidedData$probTargets, guidanceSolutions, guidedAssessments),
    function(x, y, z) {
      list(
        probTargets = x,
        variableIncomeDeltas = y,
        guidedAssessments = z
      )
    }
  )
}
