

#' Calculate Metrics for Applying Annual Flex Amounts
#'
#' This function is used to provide some flexibility on the amounts drawn down,
#' based on the (relative) performance of the investment strategy in a prior
#' years.  This is not applied cumulatively.
#'
#' @param strategyReturns matrix of returns for specified strategy
#' @param drawdownIncomeData inputs for drawdown, specifically flex limits
#' @param targetIncreaseType an increase type associated with the target (i.e.
#'   is the target inflation-linked or fixed)
#'
#' @return matrix with a mix of 1s, 0s or -1s
calculateAnnualFlexRtnMetrics <- function(strategyReturns, drawdownIncomeData,
  targetIncreaseType, essData,
  projIndices) {


  #For rpi-linked annuities use ILGs as the proxy, for all others use FIGs
  denominator <-
    switch(targetIncreaseType$increaseType,
      rpi = essData$assetClassReturns$medIlgs,
      essData$assetClassReturns$medFigs
    )

  #Calculate relative returns matrix
  relativeRtns <-
    (1 + strategyReturns) /
    (1 + denominator[projIndices, , drop = FALSE]) - 1

  #Return a matrix with +1 for relative returns above upper target, -1 for
  #relative returns below lower target, and 0 for other cases
  (-1 * (relativeRtns < drawdownConstants()$lowerFlexReturn)) +
    (1 * (relativeRtns > drawdownConstants()$upperFlexReturn))
}
