


#' Apply Vector Amount To Simulation Matrix
#'
#' Helper function to apply one amount vector to a simulation matrix
#'
#' @param amountVector vector of amounts
#' @param simData matrix of simulated data, years as rows
#'
#' @return adjusted matrix
applyVectorMatrixCalc <- function(amountVector, simData) {

  nrows <- length(amountVector)

  stopifnot(nrows <= nrow(simData))

  diag(amountVector, nrow = nrows) %*% simData[1:nrows, , drop = FALSE]
}
