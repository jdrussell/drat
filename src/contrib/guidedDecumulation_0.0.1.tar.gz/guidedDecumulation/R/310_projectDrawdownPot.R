
#' Project Drawdown Pot
#'
#' This is the main drawdown function for projecting forward the assets.
#'
#'
#' @param initialPot initial amount of assets
#' @param returns matrix of strategy returns
#' @param platformFees inputs associated with platform fees
#' @param incomeInputs list with static income, variable income and elements
#'   required for flex amounts
#'
#' @return list of matrices for projected assets and income received
projectDrawdownPot <- function(initialPot, returns, platformFees,
                                incomeInputs) {


  nproj <- dim(returns)[1] - 1
  nsim <- dim(returns)[2]

  initParams <-
    list(
      startYear = 0,
      outputList =
        list(
          assets = rep(initialPot, nsim),
          desiredIncome = rep(0, nsim),
          receivedIncome = rep(0, nsim),
          succesfulPayments = rep(0, nsim) #want this to be zero
        )
    )

  stepFn <- function(stepParams) {

    startYear = stepParams$startYear
    projIndex <- startYear + 2
    startYrIndex <- startYear + 1

    startAssets <- stepParams$outputList$assets

    #Extract specific projection vectors from matrices

    #Returns
    rtns <- returns[projIndex, ]

    #Fees due
    absoluteFees <- platformFees$absoluteFees[projIndex, ]
    assetPpnFees <- platformFees$tierFn(startAssets, projIndex)

    #Amount to flex variable income (based on previous year performance)
    flexData <- incomeInputs$flexData
    pastYearPerformanceWeights <-
      flexData$relativeRtnMetrics[startYrIndex, ]
    upFlex <- flexData$flexAmounts$upFlexAmounts[projIndex, ]
    downFlex <- flexData$flexAmounts$downFlexAmounts[projIndex, ]
    flexAmount <-
      upFlex * (pastYearPerformanceWeights > 0) +
      downFlex * (pastYearPerformanceWeights < 0)

    #Income due
    staticIncome <- incomeInputs$staticIncome[projIndex, ]
    variableDelta <- incomeInputs$variableIncomeDelta
    variableIncome <- variableDelta * incomeInputs$variableIncome[projIndex, ]

    #Amount to take out of assets (allowing for flex amounts)
    incomeToDrawdown <-
      staticIncome +
      pmax(0, variableIncome + flexAmount)

    #Pay fees first (don't let assets go below 0)
    assetsPostFees <- pmax(0, startAssets - absoluteFees - assetPpnFees)

    #Create logical vector based on whether assets have run out or not
    assetsNotRunOut <- (assetsPostFees > 0)

    #Record whether successful payment for the year can be made
    enoughMoney <- assetsPostFees >= incomeToDrawdown

    #Now set out how much can be paid (note the multiplier of assetsNotRunOut to
    #ensure nothing comes out of assets if they've run out)
    incomePaid <- assetsNotRunOut * pmin(assetsPostFees, incomeToDrawdown)

    #Assuming income paid at start  of year
    updatedAssets <- (assetsPostFees - incomePaid) * (1 + rtns)

    stepParams$startYear <- startYear + 1
    stepParams$outputList$assets <- updatedAssets
    stepParams$outputList$desiredIncome <- staticIncome + variableIncome
    stepParams$outputList$receivedIncome <- incomePaid
    stepParams$outputList$succesfulPayments <- enoughMoney
    return(stepParams)
  }

  funcall <- function(params, f) f(params)

  allSimResults <-
    purrr::accumulate(
      rep.int(list(stepFn), nproj),
      funcall,
      .init = initParams
    )

  #Need to turn list of output lists into output list of lists
  transposedOutput <-
    purrr::transpose(
      purrr::map(
        allSimResults,
        "outputList"
      )
    )
  #And then create list of matrices
  #Drop is there in case single element output is included
  purrr::map(transposedOutput, ~ drop(do.call(rbind, .x)))
}
