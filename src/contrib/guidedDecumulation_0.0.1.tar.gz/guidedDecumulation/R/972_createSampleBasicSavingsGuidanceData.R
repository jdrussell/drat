


createSampleBasicSavingsGuidanceData <- function() {
  list(
    "probTargets" = 0.5
  )
}
