
#' Calculate Survival Probabilities
#'
#' @param memberQxTable qx table based on member data
#'
#' @return dataframe of age, likelihood of being alive, and probability of death
#'   at given age
calculateSurvivalProbs <- function(memberQxTable) {

  currentAge <- min(memberQxTable$Age)
  maxQxAge <- max(memberQxTable$Age)

  startAgeYears <-
    seq.int(currentAge, by = 1, length.out = maxQxAge - currentAge)

  qx <- dplyr::filter(memberQxTable, Age %in% startAgeYears)$Qx

  survivalProbs <- c(1, cumprod(1 - qx))

  data.frame(
    age = c(currentAge, startAgeYears + 1),
    survivalProbs = survivalProbs,
    deathAtAge = survivalProbs * c(qx, 1)
  )
}

