

#' Validate Drawdown Income Inputs
#'
#' Helper function to check inputs associated with drawdown data for withdrawing
#' income
#'
#' @param drawdownIncomeData list of drawdown income inputs
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated set of income data inputs
validateDrawdownIncomeData <- function(drawdownIncomeData, maxProj) {

  #The required content of the first level of drawdown data inputs
  validDrawdownIncomeDataNames <-
    c(
      "staticIncome",
      "staticIncomeIncreaseData",
      "variableIncome",
      "variableAnnualFlexUp",
      "variableAnnualFlexDown",
      "variableIncomeIncreaseData"
    )

    #Basic check that structure of first level of inputs is correct
    assertthat::assert_that(
      is.list(drawdownIncomeData),
      all(names(drawdownIncomeData) %in% validDrawdownIncomeDataNames),
      all(validDrawdownIncomeDataNames %in% names(drawdownIncomeData))
    )

    #Check static income
    assertthat::assert_that(
      is.numeric(drawdownIncomeData$staticIncome),
      sum(drawdownIncomeData$staticIncome < 0) == 0
    )

    #Extend static income and validate increase data
    drawdownIncomeData$staticIncome <-
      extendInputsForProjectionPeriod(drawdownIncomeData$staticIncome, maxProj)

    drawdownIncomeData$staticIncomeIncreaseData <-
      validateIncreaseData(drawdownIncomeData$staticIncomeIncreaseData, maxProj)

    #Now variable income
    assertthat::assert_that(
      is.numeric(drawdownIncomeData$variableIncome),
      is.numeric(drawdownIncomeData$variableAnnualFlexUp),
      is.numeric(drawdownIncomeData$variableAnnualFlexDown),
      sum(drawdownIncomeData$variableIncome < 0) == 0,
      sum(drawdownIncomeData$variableAnnualFlexUp < 0) == 0,
      sum(drawdownIncomeData$variableAnnualFlexDown < 0) == 0,
      length(drawdownIncomeData$variableAnnualFlexUp) ==
        length(drawdownIncomeData$variableAnnualFlexDown),
      #Don't let down flex be greater than variable income target
      sum(drawdownIncomeData$variableIncome <
          drawdownIncomeData$variableAnnualFlexDown) == 0
    )

    #Extend variable income inputs
    drawdownIncomeData$variableIncome <-
      extendInputsForProjectionPeriod(drawdownIncomeData$variableIncome, maxProj)

    drawdownIncomeData$variableAnnualFlexUp <-
      extendInputsForProjectionPeriod(drawdownIncomeData$variableAnnualFlexUp,
        maxProj)

    drawdownIncomeData$variableAnnualFlexDown <-
      extendInputsForProjectionPeriod(drawdownIncomeData$variableAnnualFlexDown,
        maxProj)

    drawdownIncomeData$variableIncomeIncreaseData <-
      validateIncreaseData(drawdownIncomeData$variableIncomeIncreaseData,
        maxProj)

    return(drawdownIncomeData)
}
