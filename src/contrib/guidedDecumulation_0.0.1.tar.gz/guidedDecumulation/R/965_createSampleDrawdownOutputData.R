

createSampleDrawdownOutputData <- function() {
  list(
    summaryQuantiles = globalConstants()$stdPctiles,
    incomePaidAsReal = FALSE,
    assetsAsReal = FALSE
  )
}
