
#' Validate Drawdown Member Data Inputs
#'
#' Helper function to check inputs associated with member data for drawdown
#' products.  The required inputs are \code{age}, \code{sex}, \code{postcode},
#' and \code{relativeHealth}.
#'
#' Postcode needs to be in a valid UK format (but is not checked against
#' specific UK postcodes).  Relative health is intended to be measured relative
#' to peer group.
#'
#' @param memberData list of member data inputs for drawdown
#'
#' @return validated memberData or \code{NULL} if tests fail
validateDrawdownMemberData <- function(memberData) {

  #The required content of the member data inputs
  validMemberDataNames <-
    c(
      "age",
      "sex",
      "postcode",
      "relativeHealth"
    )

  sexChoices <-
    c(
      "male", "Male",
      "female", "Female"
    )

  validHealthChoices <- validHealthChoices()

  postcodeRegex <- '^[A-Z]{1,2}[0-9]{1,2}[A-Z]?\\s[0-9][A-Z][A-Z]$' #need to think more about this regex

  #Basic check that structure of inputs is correct
  assertthat::assert_that(
    is.list(memberData),
    all(names(memberData) %in% validMemberDataNames),
    all(validMemberDataNames %in% names(memberData))
  )

  #Now check specific cases

  #Age
  assertthat::assert_that(
    memberData$age %% 1 == 0, #alternative to is.integer
    length(memberData$age) == 1,
    memberData$age >= drawdownConstants()$minMemberAge,
    memberData$age <= drawdownConstants()$maxMemberAge
  )

  #Sex
  assertthat::assert_that(
    length(memberData$sex) == 1,
    all(memberData$sex %in% sexChoices)
  )

  #Postcode might not necessary be valid?
  #Just check format here
  assertthat::assert_that(
    grepl(postcodeRegex, memberData$postcode)
  )

  #Health choice
  assertthat::assert_that(
    length(memberData$relativeHealth) == 1,
    all(memberData$relativeHealth %in% validHealthChoices)
  )

  memberData
}

#' @describeIn validateDrawdownMemberData allowable choices for health input
validHealthChoices <- function() {
  c(
    "lessHealthy",
    "same",
    "moreHealthy"
  )
}
