

#' Calculate Weighted Probability for Drawdown Annuity Target
#'
#' @param potProjectionOutput
#' @param annuityTargetData
#' @param annuityPrices matrix of annuity prices over projection period
#' @param survivalProbs
#'
#' @return a probability
calcDrawdownWtdProbAnnuityTarget <- function(potProjectionOutput,
                                              annuityTargetData, annuityPrices,
                                              survivalProbs) {

  #For pre-target probs, need to use measure of successful payments, which
  #have an extra row of zeros as first row, so need to adjust survival probs
  #accordingly
  preTargetSuccess <- potProjectionOutput$succesfulPayments

  preTargetDeathProb <-
    c(0, survivalProbs$deathAtAge[2:nrow(preTargetSuccess) - 1])

  preTargetWtdProb <-
    sum(preTargetDeathProb * rowMeans(preTargetSuccess))

  #Now for probs at target date
  targetIndex <- annuityTargetData$targetTerm + 1

  assetsAtTarget <- potProjectionOutput$assets[targetIndex, , drop = TRUE]

  targetAmount <-
    annuityTargetData$annuityIncomePpnPreTarget *
    potProjectionOutput$desiredIncome[targetIndex, , drop = TRUE]
  targetAssets <- targetAmount * annuityPrices[targetIndex, , drop = TRUE]

  targetFloor <-
    annuityTargetData$annuityFloorPpnPreTarget *
    potProjectionOutput$desiredIncome[targetIndex, , drop = TRUE]
  targetFloorAssets <- targetFloor * annuityPrices[targetIndex, , drop = TRUE]

  #check targetAmount != targetFloor so don't divide by 0
  wtdAssets <-
    if (annuityTargetData$annuityIncomePpnPreTarget ==
        annuityTargetData$annuityFloorPpnPreTarget) {
      assetsAtTarget > targetAssets
    } else {
      pmax(0,
        pmin(1,
          (assetsAtTarget - targetFloorAssets) /
            (targetAssets - targetFloorAssets)
        )
      )
    }

  probSuccessAtTarget <- sum(wtdAssets) / length(wtdAssets)
  probSurviveToTargetDate <-
    survivalProbs$survivalProbs[nrow(preTargetSuccess)]

  #Bring them together
  preTargetWtdProb + probSurviveToTargetDate * probSuccessAtTarget

}
