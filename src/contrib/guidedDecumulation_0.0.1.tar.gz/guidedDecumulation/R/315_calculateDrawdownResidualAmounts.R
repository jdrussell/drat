

#' Calculate Target Residuals
#'
#' If the action at target age is to target a residual amount, this function
#' applies any required increases to the target and floor amounts.
#'
#' @inheritParams validateDrawdownResidualTargetData
#' @inheritParams calculateStrategyReturns
#'
#' @return list with matrix of target amounts and floor amounts
calculateDrawdownResidualTargetAmounts <- function(residualTargetData, essData,
                                                    projIndices) {

  residualIncreases <- residualTargetData$targetIncreaseData
  increaseMatrix <- applyIncrease(1, residualIncreases, essData, "flow")

  residualAmount <- residualTargetData$residualAmount
  residualFloor <- residualTargetData$residualFloor

  list(
    residualTarget =
      residualAmount * increaseMatrix[projIndices, , drop = FALSE],
    residualFloor =
      residualFloor * increaseMatrix[projIndices, , drop = FALSE]
  )
}
