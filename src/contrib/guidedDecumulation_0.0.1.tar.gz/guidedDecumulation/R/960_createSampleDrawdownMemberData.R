

#' Create Sample of Drawdown Member Data (1)
#'
#' @return list of member data inputs
createSampleDrawdownMemberData_1 <- function() {
  list(
    "age" = 65,
    "sex" = "male",
    "postcode" = "G2 6DB",
    "relativeHealth" = "same"
  )
}

#' Create Sample of Drawdown Member Data (2)
#'
#' @return list of member data inputs
createSampleDrawdownMemberData_2 <- function() {
  list(
    "age" = 55,
    "sex" = "female",
    "postcode" = "G2 6DB",
    "relativeHealth" = "same"
  )
}
