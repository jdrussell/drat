

#' Guided Spending Residual Target API Entry
#'
#' @param inputJson a json of inputs
#'
#' @return a json of outputs
#' @export
#'
#' @examples
#' sampleInputsJson <-
#' jsonlite::toJSON(guidedDecumulation:::createSampleGuideSpendingTargetResidualData_2())
#' guideResidualTargetOutputApiJson <-
#' guideSpendingResidualTargetApi(sampleInputsJson)
guideSpendingResidualTargetApi <- function(inputJson) {

  #transform json to R list
  allInputs <- jsonlite::fromJSON(inputJson)

  #Wrap the validate statements in a try catch?

  essVersion <- allInputs$essVersionData
  mortalityVersion <- allInputs$mortalityVersionData

  #load ess data
  essData <- readEssDataFromPackage(essDetails = essVersion)

  #load mortality data
  qxData <- readQxDataFromPackage(mortalityVersion)

  maxProj <- nrow(essData[[1]][[1]]) - 1

  memberData <- validateDrawdownMemberData(allInputs$memberData)
  potData <- validatePotDataInputs(allInputs$potData, maxProj)
  drawdownIncomeData <-
    validateDrawdownIncomeData(allInputs$drawdownIncomeData, maxProj)

  residualAmountTargetData <-
    validateDrawdownResidualTargetData(allInputs$residualAmountTargetData,
      maxProj)

  guidedData <-
    validateDrawdownGuidanceInputs(allInputs$residualAmountGuidanceData)

  outputData <- validateDrawdownOutputData(allInputs$outputData)

  guideOutputs <-
    decumulationProjection(
      memberData = memberData,
      potData = potData,
      drawdownIncomeData = drawdownIncomeData,
      targetData = residualAmountTargetData,
      outputData = outputData,
      guidedData = guidedData,
      essData = essData,
      qxData = qxData,
      apiOutput = TRUE)

  #transform output list to json
  jsonlite::toJSON(guideOutputs)
}
