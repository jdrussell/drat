


mortalityDataAvailable <- function() {

  #Use this to record details of mortality data available



}
