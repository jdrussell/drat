

#' Validate Drawdown Target Annuity Inputs
#'
#' Helper function to check inputs associated with drawdown data for a target of
#' an annuity purchase
#'
#' @param annuityTargetData list of inputs for targeting a residual amount
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated set of residual amount target inputs
validateDrawdownAnnuityTargetData <- function(annuityTargetData, maxProj) {

  #The required content of the first level of drawdown data inputs
  validResidualTargetNames <-
    c(
      "targetTerm",
      "annuityIncomePpnPreTarget",
      "annuityFloorPpnPreTarget",
      "targetIncreaseData"
    )

    #Basic check that structure of first level of inputs is correct
    assertthat::assert_that(
      is.list(annuityTargetData),
      all(names(annuityTargetData) %in% validResidualTargetNames),
      all(validResidualTargetNames %in% names(annuityTargetData))
    )

    #Check term, amount and floor
    assertthat::assert_that(
      is.numeric(annuityTargetData$targetTerm),
      annuityTargetData$targetTerm > 0,
      annuityTargetData$targetTerm <=  maxProj,
      is.numeric(annuityTargetData$annuityIncomePpnPreTarget),
      annuityTargetData$annuityIncomePpnPreTarget >= 0,
      is.numeric(annuityTargetData$annuityFloorPpnPreTarget),
      annuityTargetData$annuityFloorPpnPreTarget >= 0,
      annuityTargetData$annuityFloorPpnPreTarget <=
        annuityTargetData$annuityIncomePpnPreTarget
    )

    #validate increase data
    annuityTargetData$targetIncreaseData <-
      validateIncreaseData(annuityTargetData$targetIncreaseData, maxProj)

    #Add a reference to the target date
    annuityTargetData$targetRef <- "annuityTarget"

    return(annuityTargetData)

}
