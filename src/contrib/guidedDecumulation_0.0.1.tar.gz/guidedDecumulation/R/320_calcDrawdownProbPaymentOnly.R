

#' Calculate Drawdown Probability of Payments Before Death
#'
#' @param potProjectionOutput
#' @param survivalProbs
#'
#' @return a probability of paying specified amounts before death
calcDrawdownProbPaymentOnly <- function(potProjectionOutput, survivalProbs) {

  x <- rowMeans(potProjectionOutput$succesfulPayments)
  y <- c(0, head(survivalProbs$deathAtAge[seq_along(x)], -1))

  sum(x * y) / sum(y)

}
