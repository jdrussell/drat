

createSamplePotData_1 <- function() {
  list(
    "potSizePounds" = 100000,
    "potStrategy" = createSamplePotStrategy_1(),
    "platformFees" = createSamplePlatformFees_1()
  )
}

createSamplePotData_2 <- function() {
  list(
    "potSizePounds" = 100000,
    "potStrategy" = createSamplePotStrategy_2(),
    "platformFees" = createSamplePlatformFees_2()
  )
}

createSamplePotData_3 <- function() {
  list(
    "potSizePounds" = 100000,
    "potStrategy" = createSamplePotStrategy_2(),
    "platformFees" = createSamplePlatformFees_3()
  )
}
