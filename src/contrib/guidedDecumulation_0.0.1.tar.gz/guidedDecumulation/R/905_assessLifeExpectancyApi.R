

assessLifeExpectancyApi <- function(inputJson) {

  #transform json to R list
  allInputs <- jsonlite::fromJSON(inputJson)



  mortalityVersion <- allInputs$mortalityVersionData

  stop()


}
