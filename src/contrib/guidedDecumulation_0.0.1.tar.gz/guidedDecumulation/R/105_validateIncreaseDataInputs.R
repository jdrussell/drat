
#' Validate Increase Data Inputs
#'
#' Helper function to check inputs associated with increase data; currently
#' deals with 'rpi', 'fixed' and 'none' (which is a shorthand for fixed with 0%
#' increases).  'rpi' increases can also have a rate added on top (might use
#' this to mimic salary).
#'
#' @param increaseData list of inputs for increase data calcs
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated increase data
validateIncreaseData <- function(increaseData, maxProj) {

  #The required content of the increase data inputs
  validIncreaseDataNames <-
    c(
      "increaseType",
      "increaseRate"
    )

  #Allowable inputs for increase type
  validIncreaseTypes <- validIncreaseTypes()

  #Basic check that structure of first level is correct
  assertthat::assert_that(
    is.list(increaseData),
    all(names(increaseData) %in% validIncreaseDataNames),
    all(validIncreaseDataNames %in% names(increaseData))
  )

  #Now check increase types
  assertthat::assert_that(
    all(increaseData$increaseType %in% validIncreaseTypes)
  )

  #Check increase rates
  #increase rate can't be NA if increase type is "fixed"
  if (increaseData$increaseType == "fixed") {
    assertthat::assert_that(
      !is.na(increaseData$increaseRate)
    )
  }
  validatedIncreaseRate <-
    if (is.na(increaseData$increaseRate)) {
      extendInputsForProjectionPeriod(0, maxProj)
    } else {
      assertthat::assert_that(
        is.numeric(increaseData$increaseRate)
      )
      extendInputsForProjectionPeriod(increaseData$increaseRate, maxProj)
    }

  increaseData$increaseRate <- validatedIncreaseRate
  return(increaseData)
}


#' List Valid Increase Types
#'
#' Defines the available increase types that can be provided
#'
#' @return character vector of available types
validIncreaseTypes <- function() {
  c(
    "none",
    "rpi",
    "fixed"
  )
}
