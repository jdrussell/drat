


createSampleDrawdownGuidanceData <- function() {
  list(
    "probTargets" = c(0.1, 0.3, 0.5, 0.7, 0.9)
  )
}
