

createSampleAssessSavingBasicData_1 <- function() {

  sampleEssVersionData <- "testData"
  sampleLongevityVersionData <- "baseTable.RDS"

  list(
    essVersionData = sampleEssVersionData,
    longevityVersionData = sampleLongevityVersionData,
    potData = createSamplePotData_1(),
    cbnData = createSampleBasicSavingCbnData_1(),
    targetData = createSampleBasicSavingsTargetData_1(),
    outputData = createSampleBasicSavingsOutputData()
  )
}

createSampleGuideSavingBasicData_2 <- function() {

  sampleEssVersionData <- "testData"
  sampleLongevityVersionData <- "baseTable.RDS"

  list(
    essVersionData = sampleEssVersionData,
    longevityVersionData = sampleLongevityVersionData,
    potData = createSamplePotData_2(),
    cbnData = createSampleBasicSavingCbnData_2(),
    targetData = createSampleBasicSavingsTargetData_2(),
    guidanceData = createSampleBasicSavingsGuidanceData(),
    outputData = createSampleBasicSavingsOutputData()
  )
}

