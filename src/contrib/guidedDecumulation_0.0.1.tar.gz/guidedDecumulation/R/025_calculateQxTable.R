


#' Read qx Data From Package
#'
#' At least for initial testing, we will store mortality data as part of the
#' package, specifically as an RDS to be read in as part of the api call.
#'
#' @param mortalityTablesDetails
#'
#' @return list with base tables, improvement tables and postcode lookup table
#' @export
readQxDataFromPackage <- function(mortalityTablesDetails = NULL) {

  #Probably want to read in a dataframe with all base tables,
  #and also an improvement table?
  #Feather might work nicely here, as qx tables will be dataframe layout?

  #This is temporary for now, need to tidy up table
  pathToAnnuityData <-
    system.file("mortalityDataCache", "baseTable.RDS", 
      package = "guidedDecumulation", mustWork = TRUE)

  x <- readRDS(pathToAnnuityData)
  baseTable <- dplyr::filter(x, Duration == max(Duration))

  #Probably want to return a list with base & improvement tables?
  #How to deal with male / female improvements?
  list(
    baseTable = baseTable,
    improvementTable = NULL, #needs updated
    postcodeLookup = NULL
  )
}


#' Calculate qx Table
#'
#' For given member data inputs, calculate the specific qx table for that member
#'
#' @param memberDataInputs list of member data inputs
#' @param qxData data from \code{readQxDataFromPackage}
#'
#' @return a qx table
calculateQxTable <- function(memberDataInputs, qxData) {

  age <- memberDataInputs$age
  sex <- memberDataInputs$sex
  postcode <- memberDataInputs$postcode
  health <- memberDataInputs$relativeHealth

  baseTable <-
    dplyr::filter(qxData$baseTable, Age >= age, Sex == sex)
  baseTable

  #Need postcode lookup here too

  #Now want to adjust baseTable based on 'relative health' score

  #And want to apply improvement table too

}
