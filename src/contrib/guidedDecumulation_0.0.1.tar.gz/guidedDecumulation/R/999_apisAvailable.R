


drawdownProductsCovered <- function() {

  c(
    "Target annuity purchase",
    "Target residual amount"
  )

}
