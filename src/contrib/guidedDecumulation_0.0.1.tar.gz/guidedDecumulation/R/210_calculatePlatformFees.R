

#' Calculate Platform Fees
#'
#' There are two types of fees: those applied as a proportion of the assets
#' (typically tiered, with thos tiers either applying to the whole fund or to
#' 'bands'); and 'absolute' pound amount fees.  This function takes the
#' validated platform fee inputs and returns a list with two elements: a
#' function to be applied to assets in the pot projection to cover the tiered
#' fees, and a matrix of values for the absolute fees (which should be taken off
#' the assets in projection)
#'
#' @inheritParams validatePlatformFees
#' @inheritParams calculateStrategyReturns
#'
#' @return list with two elements: function to apply ppn asset fees to asset vector, and matrix with absolute fees
calculatePlatformFees <- function(platformFees, essData, projIndices) {

  ppnAssetFees <- platformFees$ppnAssets
  #create a function to apply an asset matrix to
  increasedTier <-
    purrr::map(
      ppnAssetFees$tierFloor,
      guidedDecumulation:::applyIncrease,
      increaseDataInputs = ppnAssetFees$tierFloorIncrease,
      essData = essData, stockOrFlow = "stock"
    )
  tierFeeDiffs <- #diff handles vectors of length 1 as NULL so this works
    as.list(
      c(head(ppnAssetFees$tierFeePpn, 1), diff(ppnAssetFees$tierFeePpn))
    )

  absoluteFees <-
    guidedDecumulation:::applyIncrease(
      platformFees$absoluteAmounts$feePounds[projIndices],
      platformFees$absoluteAmounts$feePoundsIncrease,
      essData,
      "flow"
    )

  list(
    tierFn =
      switch(ppnAssetFees$tierMethod,
        wholeFund = platformFeesWholeFundTierFn(increasedTier, tierFeeDiffs),
        banded = platformFeesBandedTierFn(increasedTier, tierFeeDiffs)
      ),
    absoluteFees = absoluteFees
  )
}


#' Create Fn for Tiered Platform Fees
#'
#' This creates a function that can be applied to the simulated assets at a
#' given projection period (specified by index not time) and apply tiered fees
#' (as a proportion of assets) where the tiered fee is applied in bands of asset
#' values.
#'
#' For example, on a whole fund basis a fee of 1% could apply to all assets if
#' the pot size is under £500k and a fee of 0.75% could apply to all assets if
#' the pot size is above £500k.
#'
#' On a banded basis, a fee of 1% could apply to the first £500k and a fee of
#' 0.75% could apply to any assets over £500k.
#'
#' @param increasedTier the asset value floors that fees apply from, already
#'   increased appropriately
#' @param tierFeeDiffs the initial fee and differences between subsequent fees in order to apply
#'
#' @return function taking asset vector & projection index
platformFeesBandedTierFn <- function(increasedTier, tierFeeDiffs) {
  function(assetsAtProjIndex, projIndex) {
    purrr::reduce(
      purrr::map2(
        increasedTier, tierFeeDiffs,
        ~(assetsAtProjIndex > .x[projIndex, , drop = TRUE]) *
          (assetsAtProjIndex - .x[projIndex, , drop = TRUE]) *
          .y
      ),
      `+`
    )
  }
}

#' @rdname platformFeesBandedTierFn
platformFeesWholeFundTierFn <- function(increasedTier, tierFeeDiffs) {
  function(assetsAtProjIndex, projIndex) {
    purrr::reduce(
      purrr::map2(
        increasedTier, tierFeeDiffs,
        ~(assetsAtProjIndex > .x[projIndex, , drop = TRUE]) *
          assetsAtProjIndex * .y
      ),
      `+`
    )
  }
}
