


#' Assess Spending Annuity Target API Entry
#'
#' @param inputJson a json of inputs
#'
#' @return a json of outputs
#' @export
#'
#' @examples
#' sampleInputsJson <-
#' jsonlite::toJSON(guidedDecumulation:::createSampleAssessSpendingTargetAnnuityData_1())
#' assessSpendingAnnuityTargetOutputApiJson <-
#' assessSpendingAnnuityTargetApi(sampleInputsJson)
assessSpendingAnnuityTargetApi <- function(inputJson) {

  #transform json to R list
  allInputs <- jsonlite::fromJSON(inputJson)

  #validate inputs
  validateAssessInputs(allInputs)

  essVersion <- allInputs$essVersionData
  mortalityVersion <- allInputs$mortalityVersionData
  memberData <- allInputs$memberData
  potData <- allInputs$potData
  drawdownData <- allInputs$drawdownData

  #load ess data
  essData <- readEssDataFromPackage(essDetails = essVersion)

  #load mortality data
  qxData <- readQxDataFromPackage(mortalityVersion)

  assessOutputs <-
    assessDecumulation(memberData, potData, drawdownData, essData, qxData,
      apiOutput = TRUE)

  #transform output list to json
  jsonlite::toJSON(assessOutputs)
}
