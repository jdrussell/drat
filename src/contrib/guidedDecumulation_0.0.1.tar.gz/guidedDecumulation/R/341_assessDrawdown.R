

#' Assess Drawdown
#'
#' @param commonDrawdownElements
#' @param targetData
#' @param outputData
#' @param survivalProbs
#' @param annuityPrices
#' @param apiOutput
#'
#' @return list of outputs, details of which depend on whether \code{apiOutput}
#'   is \code{TRUE} or \code{FALSE}
assessDrawdown <- function(commonDrawdownElements, targetData,
                            outputData, survivalProbs, annuityPrices,
                            apiOutput = TRUE) {

  initialPot <- commonDrawdownElements$initialPot
  returns <- commonDrawdownElements$strategyRtns
  platformFees <- commonDrawdownElements$platformFees
  incomeInputs <- commonDrawdownElements$incomeInputs

  potProjectionOutput <-
    projectDrawdownPot(initialPot, returns, platformFees, incomeInputs)

  assessProbabilities <-
    if (is.null(targetData)) {
      calcDrawdownProbPaymentOnly(potProjectionOutput, survivalProbs)
    } else {
      switch(
        targetData$targetRef,
        annuityTarget =
          calcDrawdownWtdProbAnnuityTarget(potProjectionOutput, targetData,
            annuityPrices, survivalProbs),
        residualTarget =
          calcDrawdownWtdProbResidualTarget(potProjectionOutput,
            targetData, commonDrawdownElements$targetAmounts, annuityPrices,
            survivalProbs)
      )
    }

  collateAssessDrawdownOutputs(potProjectionOutput, assessProbabilities,
    outputData, annuityPrices, survivalProbs, apiOutput)

}
