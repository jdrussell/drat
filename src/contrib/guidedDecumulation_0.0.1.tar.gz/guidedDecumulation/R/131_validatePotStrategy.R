
#' Validate Pot Strategy Inputs
#'
#' @param potStrategy list of pot strategy inputs
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated potStrategy
validatePotStrategyInputs <- function(potStrategy, maxProj) {

  #potStrategy is a list that should contain the following names
  validStrategyNames <-
    c(
      "assetClassMapping",
      "independentRiskFactorInputs",
      "fundCharges",
      "taxTreatment"
    )

  #names in assetClassMapping should be checked against ESS and random normals
  validAssetClassMappingNames <- essVariablesAvailable()$assetClassReturnsNames

  #independent risk factors need a mu and a sigma
  validRiskFactorInputNames <-
    c(
      "mu",
      "sigma"
    )

  #fund fees
  validFundChargesNames <- c("fundFeesPpnAssets")

  #tax treatment
  validTaxTreatmentNames <- c("returnAdjustment")

  #Basic check that structure of first level of inputs is correct
  assertthat::assert_that(
    is.list(potStrategy),
    all(names(potStrategy) %in% validStrategyNames),
    all(validStrategyNames %in% names(potStrategy))
  )

  #Check asset class mappings
  assertthat::assert_that(
    is.list(potStrategy$assetClassMapping),
    all(names(potStrategy$assetClassMapping) %in% validAssetClassMappingNames),
    #Don't need the reciprocal check here as may add asset classes in due
    #course?
    #Check all weights are the same length
    length(unique(purrr::map(potStrategy$assetClassMapping, length))) == 1,
    #Check sum of weights add to 100% (use 4dp)
    #Check below is that none don't add to 1
    sum(round(purrr::reduce(potStrategy$assetClassMapping, `+`),
      digits = 4) != 1.0000) == 0
  )

  assetClassMappingLen <-
    purrr::map_dbl(potStrategy$assetClassMapping, length)[[1]]

  #Check independentRiskFactorInputs
  assertthat::assert_that(
      all(names(potStrategy$independentRiskFactorInputs) %in%
        validRiskFactorInputNames),
      #need reciprocal check here (need both mu and sigma specified)
      all(validRiskFactorInputNames %in%
        names(potStrategy$independentRiskFactorInputs)),
      is.numeric(potStrategy$independentRiskFactorInputs$mu),
      is.numeric(potStrategy$independentRiskFactorInputs$sigma),
      #Check all weights are the same length
      length(unique(
        purrr::map(potStrategy$independentRiskFactorInputs, length))) == 1,
      #need asset class mappings and independent risk factors to be of same
      #length
      # purrr::map_dbl(potStrategy$independentRiskFactorInputs, length)[[1]] ==
      #   assetClassMappingLen,
      sum(potStrategy$independentRiskFactorInputs$sigma < 0) == 0
    )

  #Check fundCharges
  assertthat::assert_that(
    is.list(potStrategy$fundCharges),
    all(names(potStrategy$fundCharges) %in% validFundChargesNames)#,
    #length(potStrategy$fundCharges$fundFeesPpnAssets) == assetClassMappingLen
  )

  #Extend assetClassMapping
  potStrategy$assetClassMapping <-
    purrr::map(
      potStrategy$assetClassMapping,
      extendInputsForProjectionPeriod,
      maxProj = maxProj
    )

  #Extend independentRiskFactorInputs
  potStrategy$independentRiskFactorInputs <-
    purrr::map(
      potStrategy$independentRiskFactorInputs,
      extendInputsForProjectionPeriod,
      maxProj = maxProj
    )

  #Extend fund charges
  potStrategy$fundCharges$fundFeesPpnAssets <-
    extendInputsForProjectionPeriod(
      potStrategy$fundCharges$fundFeesPpnAssets,
      maxProj = maxProj
    )

  #Validate tax
  assertthat::assert_that(
    is.list(potStrategy$taxTreatment),
    all(names(potStrategy$taxTreatment) %in% validTaxTreatmentNames),
    is.numeric(potStrategy$taxTreatment$returnAdjustment),
    #Small attempt to make sure not providing the wrong unit of input
    sum(potStrategy$taxTreatment$returnAdjustment < -1) == 0,
    sum(potStrategy$taxTreatment$returnAdjustment > 1) == 0
  )
  #extend tax treatment
  potStrategy$taxTreatment$returnAdjustment <-
    extendInputsForProjectionPeriod(
      potStrategy$taxTreatment$returnAdjustment,
      maxProj
    )

  #Return validated pot strategy
  return(potStrategy)
}


