
#' List of Drawdown Constants
#'
#' @return list with various constants used in package functions
drawdownConstants <- function() {

  list(
    maxProjectionAge = 120,
    minMemberAge = 55,
    maxMemberAge = 75,
    minTargetAge = 65,
    maxTargetAge = 120,
    maxNumberOfProbTargets = 10,
    lowerFlexReturn = -0.05,
    upperFlexReturn = 0.1
  )
}
