

#' Extend Inputs for Projection Period
#'
#' Takes single or smaller than projection period inputs and extends them to be
#' consistent with the projection periods available by repeating the last number
#' over the whole period.  Note this also adds a 0 to the vector to be
#' consistent with the way return data is stored (i.e. with a time zero entry)
#'
#' @param inputData vector of input data (could be a single number)
#' @param maxProj maximum number of projection steps (not length of vector),
#'   typically from ESS data
#'
#' @return a vector of length maxProj + 1
extendInputsForProjectionPeriod <- function(inputData, maxProj) {
  assertthat::assert_that(
    maxProj > 0,
    length(maxProj) == 1,
    is.numeric(inputData),
    is.numeric(maxProj)
  )
  x <-
    #If vector is already same length as projection period do nothing here
    if (length(inputData) >= maxProj) {
      inputData[1:maxProj]
    } else {
      #extend by difference between projection period and length
      c(
        inputData,
        rep.int(tail(inputData, 1), maxProj - length(inputData))
      )
    }
  #want to add a zero to the vector to work with
  c(0, x)
}
