

#' Calculate Static Income Drawdown Amounts
#'
#' Project the 'static' element of drawdown income
#'
#' This is the portion of drawdown income that can't be varied by the guidance
#' optimisers.
#'
#' Note that the drawdown income inputs should already have been validated.
#'
#' @inheritParams validateDrawdownIncomeData
#' @inheritParams calculateStrategyReturns
#'
#' @return a matrix of 'static' drawdown amounts
calculateDrawdownStaticIncome <- function(drawdownIncomeData, essData,
                                          projIndices) {


  staticAmount <- drawdownIncomeData$staticIncome[projIndices]
  staticIncreases <- drawdownIncomeData$staticIncomeIncreaseData

  applyIncrease(staticAmount, staticIncreases, essData, "flow")

}


#' Calculate Drawdown Annual Flex Amounts
#'
#' Project the annual flex amounts that the variable income could move by.
#'
#' Note that the drawdown income inputs should already have been validated.
#'
#' @inheritParams validateDrawdownIncomeData
#' @inheritParams calculateStrategyReturns
#'
#' @return a list with two matrices, one for 'up' flex and one for 'down' flex
#'   amounts
calculateDrawdownAnnualFlexAmounts <- function(drawdownIncomeData, essData,
                                                projIndices) {


  upFlexAmount <-
    drawdownIncomeData$variableAnnualFlexUp[projIndices]
  downFlexAmount <-
    drawdownIncomeData$variableAnnualFlexDown[projIndices]
  variableIncreases <- drawdownIncomeData$variableIncomeIncreaseData

  list(
    upFlexAmounts =
      applyIncrease(upFlexAmount, variableIncreases, essData, "flow"),
    downFlexAmounts =
      applyIncrease(downFlexAmount, variableIncreases, essData, "flow")
  )

}

#' Calculate Variable Drawdown Amounts
#'
#' Projecting the variable element of the proposed income amount based on
#' increases provided.  Keep this separate from the other drawdown income
#' projections as this function may be called multiple times as part of the
#' optimising.
#'
#' @inheritParams validateDrawdownIncomeData
#' @inheritParams calculateStrategyReturns
#'
#' @return a matrix of variable drawdown amounts
calculateDrawdownVariableIncome <- function(drawdownIncomeData, essData,
                                            projIndices) {

  variableAmount <- drawdownIncomeData$variableIncome[projIndices]
  variableIncreases <- drawdownIncomeData$variableIncomeIncreaseData

  applyIncrease(variableAmount, variableIncreases, essData, "flow")

}
