


#' Create Sample Input Data
#'
#' @return a list with sample input data
createSampleInputData <- function() {

  sampleEssVersionData <- "testData"
  sampleMortalityVersionData <- "baseTable.RDS"

  list(
    essVersionData = sampleEssVersionData,
    mortalityVersionData = sampleMortalityVersionData,
    memberData = createSampleMemberData(),
    potData = createSamplePotData(),
    drawdownData = createSampleDrawdownData(),
    guidanceData = createSampleGuidanceData(),
    outputData = createSampleOutputData()
  )
}

createSampleDrawdownData <- function() {
  list(
    "preTargetIncomePounds" = 4000,
    "preTargetAnnualFlexUpPounds" = 200,
    "preTargetAnnualFlexDownPounds" = 200,
    "preTargetIncreaseData" =
      list(
        "increaseType" = "rpi",
        "increaseRate" = NA
      ),
    "targetAge" = 80,
    "actionAtTarget" = "targetAnnuity",
    "targetAmount" = 1.0,
    "targetFloor" = 0.8,
    "targetIncreaseData" =
      list(
        "increaseType" = "rpi",
        "increaseRate" = NA
      )
  )
}




