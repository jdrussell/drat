
#' Validate Platform Fees Inputs
#'
#' @param platformFees list of inputs associated with pot data
#' @inheritParams extendInputsForProjectionPeriod
#'
#' @return validated fee inputs
validatePlatformFees <- function(platformFees, maxProj) {

  validFeeNames <-
    c(
      "ppnAssets",
      "absoluteAmounts"
    )

  #Basic check that structure of first level of inputs is correct
  assertthat::assert_that(
    is.list(platformFees),
    all(names(platformFees) %in% validFeeNames),
    all(validFeeNames %in% names(platformFees))
  )

  #Validate fees as pct asset value
  platformFees$ppnAssets <-
    validatePlatformFeesPpnAssets(platformFees$ppnAssets, maxProj)

  #Check absolute fees in pounds
  platformFees$absoluteAmounts <-
     validatePlatformFeesAbsoluteAmounts(platformFees$absoluteAmounts, maxProj)

  #Return validated fees
  return(platformFees)

}


validatePlatformFeesPpnAssets <- function(ppnAssetFees, maxProj) {

  validPpnAssetFeeNames <-
    c(
      "tierFloor",
      "tierFeePpn",
      "tierFloorIncrease",
      "tierMethod"
    )

  assertthat::assert_that(
    is.list(ppnAssetFees),
    all(names(ppnAssetFees) %in% validPpnAssetFeeNames),
    all(validPpnAssetFeeNames %in% names(ppnAssetFees))
  )

  #Checks on floor and ppn
  assertthat::assert_that(
    is.numeric(ppnAssetFees$tierFloor),
    is.numeric(ppnAssetFees$tierFeePpn),
    length(ppnAssetFees$tierFloor) == length(ppnAssetFees$tierFeePpn),
    sum(ppnAssetFees$tierFloor < 0) == 0,
    sum(ppnAssetFees$tierFeePpn < 0) == 0
  )

  assertthat::assert_that(
    ppnAssetFees$tierMethod %in% validPlatformFeeTierMethods()
  )

  #validate tier floor increase
  ppnAssetFees$tierFloorIncrease <-
    validateIncreaseData(ppnAssetFees$tierFloorIncrease, maxProj)

  return(ppnAssetFees)
}

validPlatformFeeTierMethods <- function() {
  c(
    "banded",
    "wholeFund"
  )
}
validatePlatformFeesAbsoluteAmounts <- function(absoluteAmounts, maxProj) {

  validAmountNames <-
    c(
      "feePounds",
      "feePoundsIncrease"
    )

  assertthat::assert_that(
    is.list(absoluteAmounts),
    all(names(absoluteAmounts) %in% validAmountNames),
    all(validAmountNames %in% names(absoluteAmounts))
  )

  assertthat::assert_that(
    is.numeric(absoluteAmounts$feePounds)
  )

  #Extend amounts
  absoluteAmounts$feePounds <-
    extendInputsForProjectionPeriod(absoluteAmounts$feePounds, maxProj)

  #Validate increases
  absoluteAmounts$feePoundsIncrease <-
    validateIncreaseData(absoluteAmounts$feePoundsIncrease, maxProj)

  return(absoluteAmounts)
}
