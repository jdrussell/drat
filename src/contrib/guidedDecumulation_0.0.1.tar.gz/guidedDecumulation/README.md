# guidedDecumulation 

The purpose of this package is to provide the functions required by our various apis.  The api functions included with this package provide analytics helping an individual **assess** their choices relative to some target objective, as well as providing **guidance** for withdrawal amounts relative to some target objective.  

This vignette provides a brief summary of each API function included in the package.  Further information on each API can be found in separate vignettes.

### General information calls

- *availableEconomicScenarioCalibrations*  

- *availableLongevityCalibrations*  

- *assessLifeExpectancy*  


### Accumulation APIs  

- *assessSavingBasic*  

- *guideSavingBasic*  

The above functions cover both ISA and general investment vehicles.  
  
- *assessSavingPension*  
- *guideSavingPension*  

These functions relate to the calculation engine underlying our GO Save platform.  

### Decumulation APIs  

- *assessSpendingResidualTarget*  
- *guideSpendingResidualTarget*  

The above functions would relate to drawdown where the customer objective is to withdraw a steady level of income up to a target date and, at that date, to have a specific amount left in their pot.  
  
- *assessSpendingAnnuityTarget*  
- *guideSpendingAnnuityTarget*  

These functions relate to drawdown where the customer objective is to withdraw a steady level of income up to a target date and, at that date, to purchase an annuity.   

