﻿param
(
	[string] $ApiManagementResourceGroupName,
	[string] $ApiManagementServiceName,
    [string] $ApiName,
    [string] $SwaggerPath,
    [string] $ApiEnvironment,
	[string] $ProductName
)

$apiMgmtContext = New-AzureRmApiManagementContext -ResourceGroupName $ApiManagementResourceGroupName -ServiceName $ApiManagementServiceName

Write-Host ($apiMgmtContext | Format-Table | Out-String)

$apiPath = $ApiName

if ($ApiEnvironment)
{
   $apiPath = $ApiEnvironment + "/" + $apiPath 
}

$existingApi =  Get-AzureRmApiManagementApi -Context $apiMgmtContext | Where-Object { $_.Path -eq $apiPath }

if (!$existingApi){

    Write-Host "Creating new API from Swagger definition"

	$apiId = [System.Guid]::NewGuid()

} else {
    
    Write-Host "API already exists, updating from Swagger definition"

    $apiId = $existingApi.ApiId

	Write-Host "API ID is $apiId"
}

$apiContext = Import-AzureRmApiManagementApi -Context $apiMgmtContext -SpecificationFormat "Swagger" -SpecificationPath $SwaggerPath -Path $apiPath -ApiId $apiId

Write-Host ($apiContext | Format-Table | Out-String)

if ($ProductName)
{
	Write-Host "Adding API to product"

	$product = Get-AzureRmApiManagementProduct -Context $apiMgmtContext -Title $ProductName
	Add-AzureRmApiManagementApiToProduct -Context $apiMgmtContext -ProductId $product.ProductId -ApiId $ApiContext.ApiId
}