﻿Param (
	[string]$packageFileName = $(throw “Package file name must be supplied”) 
)

# [JR] TODO: Ultimately this script becomes a 'install on Hymans API miniCRAN script such that tarball does not need copied to MRSO.
# MRSO will point to Hymans API miniCRAN and the normal deploy script can just list the API package as a dependency and carry out a normal install.packages(...) with it

$rExe = "RScript"

function InstallDependentPackages() 
{	
	$deployJson = "deploy.json"	
	$config = (Get-Content $deployJson -Raw) | ConvertFrom-Json
	$rPackageInstaller = "PackageInstaller.R"

	# install package dependencies for all functions to be deployed
	foreach ($function in $config)
	{
		$rDependentPackages = (ConvertTo-Json $function.packages -Compress).replace("`"", "`\`"")
		Write-Output "rDependentPackages Value :" $rDependentPackages				
		$params = "$rPackageInstaller '$rDependentPackages'"					
		Write-Verbose "Running R package installer  script" -Verbose
		$output = Invoke-Expression "$rExe $params"
		Write-Verbose "Output of R script: $output" -Verbose
		if ($output -like "*R package installer exception: *") { throw $output }
	}
}

function InstallModelPackage()
{
	$packageFileName = $packageFileName.Replace("\", "\\")
	Write-Output "packageFileName Value :" $packageFileName
	$rCopyScript = "RemotePackageCopy.R"	
	$params = "$rCopyScript $packageFileName"
	$output = Invoke-Expression "$rExe $params"
	Write-Verbose "Output of R script: $output" -Verbose
	if ($output -like "*R remote package copy exception: *") { throw $output }
}

try
{
	InstallDependentPackages
	InstallModelPackage
}						
catch [System.Exception]
{
	# Rollback if necessary
	Write-Output "Error during remote package copy" 
	Write-Output $_.Exception.Message 
		
	# Flag error so it is picked up by VSTS
	throw "R remote package copy failed" 
	exit 1
}