library(mrsdeploy)
library(jsonlite)

args <- commandArgs(trailingOnly = TRUE)

displayProperties <- function() {
    message("rDependentPackages: ", rDependentPackages)
}

setProperties <<- function() {
    rDependentPackages <<- fromJSON(gsub("'", "\"", args[1])) # list of dependent packages for rFunction to be deployed, e.g. jsonlite, the name of the R API model package that rFunction calls into    
    displayProperties()
}

setProperties()

hasDependentPackages <- (length(rDependentPackages) > 0)

loadDependentPackages <- function() {
    message("installing dependent packages")

    #[JR] TODO: Can't get this approach working
    #putLocalObject("rDependentPackages")
    #remoteExecute("install.packages(eval(parse(text = \"rDependentPackages\")))",script=FALSE)		

    packages <- paste("'", rDependentPackages, "'", sep = "", collapse = ",")
    packageCollection <- paste("c(", packages, ")", sep = "", collapse = "'")
    command <- paste("install.packages(", packageCollection, ")", sep = "", collapse = "'")
    message("command: ", paste("\"", command, "\"", sep = "", collapse = ""))
    remoteExecute(command, script = FALSE)
    #[JR] this currently fails (silently, here) due to large/numerous dependency (?) packages on MRSO
    #snapshotId <- createSnapshot("guidedDecumulation")
}

tryCatch({
    # Mrsdeploy connect to target R server
    remoteLogin("__RServer__",
                session = TRUE,
                diff = FALSE,
                commandline = FALSE,
                username = "__RServerUsername__",
                password = "__RServerPassword__")
    message("remote login to MRSO successful")

    if (hasDependentPackages) {
        loadDependentPackages()
    }

    remoteLogout()
}, error = function(e) {
    failureMessage <- c("R package installer exception: ", as.character(e))
    return(failureMessage)
})