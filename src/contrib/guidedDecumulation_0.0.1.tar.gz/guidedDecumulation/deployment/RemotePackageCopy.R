tryCatch({
    library(mrsdeploy)
    args <- commandArgs(trailingOnly = TRUE)
    packageFileName <<- args[1]

    remoteLogin("__RServer__",
                session = TRUE,
                diff = FALSE,
                commandline = FALSE,
                username = "__RServerUsername__",
                password = "__RServerPassword__")

    message("remote login to MRSO successful")
    putLocalFile(packageFileName)
    message("package successfully copied to MRSO")

    #[JR] currently just simulating loading a snapshot as it only works with the git2r and optimx packages installed, not all dependencies
    #[JR] as it stands, all dependencies have been installed via a R script on each of the compute node (in dev) - MS Option 2 for package management - due to snapshot issues
    message("loading dependencies snapshot")
    #loadSnapshot("48c3e9ce-99eb-4a7e-948e-7177a73cb1a1")

    remoteExecute("install.packages(list.files(getwd(), pattern = \"*.tar.gz\"))", script = FALSE)
    message("package successfully installed package to MRSO")

    message("deleting previous snapshot")
    #deleteSnapshot("48c3e9ce-99eb-4a7e-948e-7177a73cb1a1")
    message("creating new snapshot")
    #createSnapshot("guidedDecumulation")

    remoteLogout()

}, error = function(e) {
    failureMessage <- c("R remote package copy exception: ", as.character(e))
    return(failureMessage)
})