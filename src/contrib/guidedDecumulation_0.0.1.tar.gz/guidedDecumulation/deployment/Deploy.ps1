﻿Param (	
	[string]$functionVersion = $(throw “Function version must be supplied”)	
)

$ErrorActionPreference = "Stop"

$deployJson = "deploy.json"
$rDeployScript = "Deploy.R"
$rExe = "RScript"
$config = (Get-Content $deployJson -Raw) | ConvertFrom-Json

function DisplayConfiguration()
{
	Write-Output "rFunctionFile Value :" $rFunctionFile	
	Write-Output "rFunction Value :" $rFunction
	Write-Output "inputSchema Value :" $inputSchema
	Write-Output "outputSchema Value :" $outputSchema
	Write-Output "function Version Value :" $functionVersion
	Write-Output "rDependentPackages Value :" $rDependentPackages
}

$ErrorActionPreference = "Stop"

$deployJson = "deploy.json"
$rDeployScript = "Deploy.R"
$rExe = "RScript"
$config = (Get-Content $deployJson -Raw) | ConvertFrom-Json

function DisplayConfiguration()
{
	Write-Output "rFunctionFile Value :" $rFunctionFile	
	Write-Output "rFunction Value :" $rFunction
	Write-Output "inputSchema Value :" $inputSchema
	Write-Output "outputSchema Value :" $outputSchema
	Write-Output "function Version Value :" $functionVersion
	Write-Output "rDependentPackages Value :" $rDependentPackages
	Write-Output "rModelPackage Value :" $rModelPackage
}

function Deploy()
{
	try
	{
		foreach ($function in $config)
		{
			Write-Verbose "Setting params" -Verbose			
			$rFunctionFile = $function.script
			$rFunction = $function.function
			$inputSchema = (ConvertTo-Json $function.inputSchema -Compress).replace("`"", "`\`"")
			$outputSchema = (ConvertTo-Json $function.outputSchema -Compress).replace("`"", "`\`"")
			$rDependentPackages = (ConvertTo-Json $function.packages -Compress).replace("`"", "`\`"")
			$rModelPackage = $function.modelPackage
			DisplayConfiguration					
			$params = "$rDeployScript $rFunctionFile $rFunction '$inputSchema' '$outputSchema' $functionVersion '$rDependentPackages' $rModelPackage"					
			Write-Verbose "Running R Deploy script" -Verbose
			$output = Invoke-Expression "$rExe $params"
			Write-Verbose "Output of R script: $output" -Verbose
			if ($output -like "*R API deploy exception: *") { throw $output }
		}						
	}
	catch [System.Exception]
	{
		# Rollback if necessary
		Write-Output "Error during deployment" 
		Write-Output $_.Exception.Message 
		
		# Flag error so it is picked up by VSTS
		throw "R API deployment failed" 
		exit 1
	}
}

Deploy -ErrorAction Stop | Write-Verbose -Verbose