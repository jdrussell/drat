#
# Configure_ApiPolicy.ps1
#
# - Programmatically configures the policy at an API level
#

Param(
	[string] $ApiManagementResourceGroupName = $(throw "Resource Group Name must be supplied"),
	[string] $ApiManagementServiceName  = $(throw "API Management Service Name must be supplied"),
	[string] $ApiName  = $(throw "API Name must be supplied"),
	[string] $PolicyPath  = $(throw "Path to Policy file must be supplied")
)

Write-Host "Configuring policy for API: $ApiName"
try {

	# Get APIM context
	$apiMgmtContext = New-AzureRmApiManagementContext -ResourceGroupName $ApiManagementResourceGroupName -ServiceName $ApiManagementServiceName
	Write-Host ($apiMgmtContext | Format-Table | Out-String)

	# Get API
	$existingApi = Get-AzureRmApiManagementApi -Context $apiMgmtContext | Where-Object { $_.Path -eq $ApiName }
	if ($existingApi) {
		$apiId = $existingApi.ApiId
		Write-Host "Setting Policy for API - ApiId: $ApiId Context: $apiMgmtContext PolicyPath: $PolicyPath"

		$result = Set-AzureRmApiManagementPolicy -ApiId $apiId -Context $apiMgmtContext -PolicyFilePath $PolicyPath -Format application/vnd.ms-azure-apim.policy.raw+xml

		Write-Host "Policy applied to API: $ApiName"
	} else {
		Write-Host "API does not exist - No policy applied"
	}
}
catch [System.Exception]
{
	Write-Error "Error configuring policy for API: [$ApiName]" $_.Exception.Message -Verbose
}



