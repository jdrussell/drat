library(mrsdeploy)
library(jsonlite)

args <- commandArgs(trailingOnly = TRUE)

displayProperties <- function() {
    message("rScript: ", rScript)
    message("rFunctionName: ", rFunctionName)
    message("rFunction: ", rFunction)
    message("rInputSchema: ", rInputSchema)
    message("rOutputSchema: ", rOutputSchema)
    message("inputsDefinition: ", inputsDefinition)
    message("outputsDefinition: ", outputsDefinition)
    message("functionVersion: ", functionVersion)
    message("rDependentPackages: ", rDependentPackages)
    message("rModelPackage: ", rModelPackage)
}

setProperties <<- function() {
    rScript <<- args[1] # The .R file that contains the function to be deployed to MRSO
    rFunctionName <<- args[2] # The name identifier assigned to the web service in MRSO
    rFunction <<- args[2] # The name of the function in rScript that is to be deployed    
    rInputSchema <<- gsub("'", "\"", args[3]) # The input schema of the function to be deployed
    rOutputSchema <<- gsub("'", "\"", args[4]) # The output schema of the function to be deployed
    functionVersion <<- args[5] # The version of the deployed function
    rDependentPackages <<- fromJSON(gsub("'", "\"", args[6])) # - separated list of dependent packages for rFunction to be deployed, e.g. jsonlite, the name of the R API model package that rFunction calls into
    inputsDefinition <<- lapply(as.list(fromJSON(rInputSchema)), function(x) x[!is.na(x)])
    outputsDefinition <<- lapply(as.list(fromJSON(rOutputSchema)), function(x) x[!is.na(x)])
    rModelPackage <<- args[7] # The model package that the deployed API function calls into
    displayProperties()
}

setProperties()

hasDependentPackages <- (length(rDependentPackages) > 0)
hasModelPackage <- (rModelPackage != "NA")
validArguments <- (length(args) == 7)

loadDependentPackages <- function() {
    if (hasDependentPackages) {
        #[JR] currently just simulating loading a snapshot as it only works with the git2r and optimx packages installed, not all dependencies
        #[JR] as it stands, all dependencies have been installed via a R script on each of the compute node (in dev) - MS Option 2 for package management - due to snapshot issues
        message("loading dependencies snapshot")
        #loadSnapshot("48c3e9ce-99eb-4a7e-948e-7177a73cb1a1")
        packages <- paste("'", rDependentPackages, "'", sep = "", collapse = ",")
        packageCollection <- paste("c(", packages, ")", sep = "", collapse = "'")
        command <- paste("library(", packageCollection, ",lib.loc=getwd())", sep = "", collapse = "'")
        message("command: ", paste("\"", command, "\"", sep = "", collapse = ""))
        remoteExecute(command, script = FALSE)
    }
}

loadModelPackage <- function() {
    if (hasModelPackage) {
        command <- paste("library('", rModelPackage, "')", sep = "", collapse = "'") #[JR] TODO: update to latest version of the model package from MaaS mini CRAN
        message("command: ", paste("\"", command, "\"", sep = "", collapse = ""))
        remoteExecute(command, script = FALSE)
    }
}

if (!validArguments) {
    stop("Deploy.R requires 7 input arguments.n", call. = FALSE)
}

tryCatch({
    # Mrsdeploy connect to target R server
    remoteLogin("__RServer__",
                session = TRUE,
                diff = FALSE,
                commandline = FALSE,
                username = "__RServerUsername__",
                password = "__RServerPassword__")
    message("remote login to MRSO successful")

    # Load in the content of the rScript file
    source(rScript)
    rFunctionToDeploy <- get(rFunction)
    loadDependentPackages()
    loadModelPackage()
}, error = function(e) {
    failureMessage <- c("R API deploy exception: ", as.character(e))
    return(failureMessage)
})

installOrUpdate <- function() {
    #[JR] must be a better way than using exception handling for control flow!
    tryCatch({
        # Publish function
        api <- getService(
            as.character(rFunctionName),
            as.character(functionVersion))
        "update"
    }, error = function(e) {
        "install"
    })
}

tryCatch({
    if (as.character(installOrUpdate()) == "install") {
        publishService(
            name = rFunctionName,
            code = rFunctionToDeploy,
            model = NULL,
            inputs = inputsDefinition,
            outputs = outputsDefinition,
            v = functionVersion)
    }
    else {
        updateService(
            name = rFunctionName,
            code = rFunctionToDeploy,
            model = NULL,
            inputs = inputsDefinition,
            outputs = outputsDefinition,
            v = functionVersion)
    }
    message("MRSO function deployment completed successfully")
    remoteLogout()
}, error = function(e) {
    failureMessage <- c("R API deploy exception: ", as.character(e))
    return(failureMessage)
})