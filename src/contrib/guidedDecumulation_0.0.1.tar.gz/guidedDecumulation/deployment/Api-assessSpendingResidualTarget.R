assessSpendingResidualTargetApi <- function(inputJson) {

    #transform json to R list
    allInputs <- jsonlite::fromJSON(inputJson)

    #Wrap the validate statements in a try catch?

    essVersion <- allInputs$essVersionData
    mortalityVersion <- allInputs$mortalityVersionData

    #load ess data
    essData <- guidedDecumulation:::readEssDataFromPackage(essDetails = essVersion)

    #load mortality data
    qxData <- guidedDecumulation:::readQxDataFromPackage(mortalityVersion)

    maxProj <- nrow(essData[[1]][[1]]) - 1

    memberData <- guidedDecumulation:::validateDrawdownMemberData(allInputs$memberData)
    potData <- guidedDecumulation:::validatePotDataInputs(allInputs$potData, maxProj)
    drawdownIncomeData <-
        guidedDecumulation:::validateDrawdownIncomeData(allInputs$drawdownIncomeData, maxProj)

    residualAmountTargetData <-
        guidedDecumulation:::validateDrawdownResidualTargetData(allInputs$residualAmountTargetData,
        maxProj)

    outputData <- guidedDecumulation:::validateDrawdownOutputData(allInputs$outputData)

    assessOutputs <-
        guidedDecumulation:::decumulationProjection(
        memberData = memberData,
        potData = potData,
        drawdownIncomeData = drawdownIncomeData,
        targetData = residualAmountTargetData,
        outputData = outputData,
        guidedData = NULL,
        essData = essData,
        qxData = qxData,
        apiOutput = TRUE)

    #transform output list to json
    jsonlite::toJSON(assessOutputs)
}