
library(tidyverse)
library(readxl)

#Location of this script & associated files
cacheScriptFolder <- "createEssDataCache"
dataCacheAudit <- read_csv(file.path(cacheScriptFolder, "dataCacheAudit.csv"))
essMappings <- read_excel(file.path(cacheScriptFolder, "essMappings.xlsx"))

#Location to store essData (assumes this file is accessed from the package)
essCacheFolder <- file.path("inst", "essDataCache")

#set number of sims to store
nsim <- 1000

#set number of years to store
nproj <- 70

#Define some standalone helper functions
readEssCsv <- function(filename, sourceFolder, maxSim, maxYrs) {
  read_csv(file.path(sourceFolder, paste0(filename, ".csv"))) %>%
    t() %>% #transpose to get matrix of yrs by sims
    .[0:nproj + 1, 1:nsim]
}

getAllEssData <- function(sourceFolder) {

  groupNames <- unique(essMappings$group)
  #Read in raw data
  initialData <-
    map(
      groupNames,
      function(x) {
      filteredMappings <- filter(essMappings, group == x)
      filteredMappings$essFilename %>%
        map(readEssCsv, sourceFolder, nsim, nproj) %>%
        set_names(filteredMappings$friendlyName)
    }) %>%
    set_names(groupNames)

  #Need to make an adjustment for RPI index and for corporate spreads
  initialData$economicData$rpiActualIndex <-
    apply(1 + initialData$economicData$rpiActual, 2, cumprod)

  #There's a slight issue with maturities at the moment but just wanted to get
  #this working
  initialData$economicData$corpSpread_AA <-
    initialData$economicData$corpYield_AA -
    initialData$economicData$giltsNominalYield

  #now create and add on iid normals
  set.seed(1.234)
  normalMatrix_1 <-
    rbind(
      rep.int(0, nsim),
      matrix(rnorm(nsim * nproj), nrow = nproj)
    )

  iidNormals <- list(iidNormal_1 = normalMatrix_1)

  c(
    initialData,
    list(
      iidNormals = iidNormals
    )
  )
}


cacheEssData <- function(sourceFolder, outputFolder) {

  outputPath <- file.path(getwd(), essCacheFolder, outputFolder)

  #check output directory exists
  if (!dir.exists(outputPath)) {
    dir.create(outputPath)
  }

  essData <- getAllEssData(sourceFolder = sourceFolder)

  saveRDS(essData, file.path(outputPath, "essData.RDS"))

  #return cache date
  format(Sys.time(), "%H:%M %A, %d %B %Y")
}


loopThroughCacheAudit <- function(cacheAudit) {

  cacheAudit$calibRef %>%
    map_chr(function(x) {
      y <- filter(cacheAudit, calibRef == x)
      if (!is.na(y$rdsCreated)) {
        y$rdsCreated
      } else {
        cacheEssData(y$calibSourceData, y$calibOutFolder)
      }
    })
}


dataCacheAudit$rdsCreated <- loopThroughCacheAudit(dataCacheAudit)

write_csv(dataCacheAudit, file.path(cacheScriptFolder, "dataCacheAudit.csv"))
