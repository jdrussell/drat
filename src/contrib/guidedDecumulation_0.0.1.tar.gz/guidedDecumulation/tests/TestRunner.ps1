﻿Param (
	#full path to tests directory from package root
	[string]$testsPath = $(throw “Tests path must be supplied”), 
	[string]$packageToTest = $(throw “Package to test must be supplied”)
)

try
{
	$testsPath = $testsPath.Replace("\", "\\")

	Write-Output "testsPath Value :" $testsPath
	Write-Output "packageToTest Value :" $packageToTest

	$testRunner = "TestRunner.R"
	$rExe = "RScript"
	$params = "$testRunner $testsPath $packageToTest"	
	Write-Output "Calling TestRunner.R"
	$output = Invoke-Expression "$rExe $params"
	Write-Verbose "Output of R script: $output" -Verbose
	if ($output -like "*R unit test run exception: *") { throw $output }
}
catch [System.Exception]
{
	# Rollback if necessary
	Write-Output "Error running unit tests" 
	Write-Output $_.Exception.Message 
		
	# Flag error so it is picked up by VSTS
	throw "R unit test run failed" 
	exit 1
}