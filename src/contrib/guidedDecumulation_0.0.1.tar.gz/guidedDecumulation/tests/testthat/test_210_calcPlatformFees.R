library(guidedDecumulation)
context("Calc platform fees")


testEssData <-
  list(
    economicData =
      list(
        rpiActualIndex =
          matrix(
            c(1, 1.03, 1.03 * 1.04, 1.03 * 1.04 * 1.05,
              1, 1.01, 1.01 * 1.02, 1.01 * 1.02 * 1.03),
            nrow = 4, ncol = 2
          )
      )
  )
platformIncrease_none <-
  list(
    increaseType = "none",
    increaseRate = NA
  )
platformIncrease_rpi <-
  list(
    increaseType = "rpi",
    increaseRate = NA
  )

tierValue_1 <- 0
tierValue_2 <- c(0, 250, 500)
tier_value_3 <- c(250, 500, 750)

tierFee_1 <- 0
tierFee_2 <- c(0.01, 0.0075, 0.005)
tierFee_3 <- c(0.005, 0.0075, 0.01)

tierMethod_1 <- "wholeFund"
tierMethod_2 <- "banded"

testAssets_1 <- 150
testAssets_2 <- c(0, 100, 300, 350, 550, 500, 700, 750, 790, 1000)

fees <- list(
  "ppnAssets" =
    list(
      "tierFloor" = tierValue_1,
      "tierFeePpn" = tierFee_1,
      "tierFloorIncrease" = platformIncrease_none,
      "tierMethod" = tierMethod_1
    ),
  "absoluteAmounts" =
    list(
      "feePounds" = 100,
      "feePoundsIncrease" =
        list(
          "increaseType" = "rpi",
          "increaseRate" = NA
        )
    )
)

f <- function(fees, essData, projIndices) {
  guidedDecumulation:::calculatePlatformFees(fees, essData, projIndices)
}

test_that(
  "returns a list with the right elements", {

    fees <-
      guidedDecumulation:::validatePlatformFees(
        guidedDecumulation:::createSamplePlatformFees_1(),
        3
      )

    expect_true(is.list(f(fees, testEssData, 1:4)))
    expect_true(length(f(fees, testEssData, 1:4)) == 2)
  }
)

test_that(
  "returns correct % fees", {

    #no fees
    assetValue = c(100, 100)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(0, 0)
    expect_equal(result, expected)


    #no fees, zero asset value
    assetValue = c(0, 0)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(0, 0)
    expect_equal(result, expected)


    #10% fees, single tier
    fees$ppnAssets$tierFeePpn <- 0.1
    fees$ppnAssets$tierMethod <- "wholeFund"

    assetValue = c(100, 100)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(10, 10)
    expect_equal(result, expected)

    fees$ppnAssets$tierFeePpn <- 0.1
    fees$ppnAssets$tierMethod <- "banded"

    assetValue = c(100, 100)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(10, 10)
    expect_equal(result, expected)


    #two tiers, banded method, no increases
    fees$ppnAssets$tierFloor <- c(0,100)
    fees$ppnAssets$tierFeePpn <- c(0.1, 0.2)
    fees$ppnAssets$tierMethod <- "banded"

    assetValue = c(100, 100)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(10, 10)
    expect_equal(result, expected)

    assetValue = c(150, 150)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(100 * 0.1 + 50 * 0.2, 100 * 0.1 + 50 * 0.2)
    expect_equal(result, expected)


    #three tiers, wholefund method, no increases
    fees$ppnAssets$tierFloor <- c(0, 100, 250)
    fees$ppnAssets$tierFeePpn <- c(0.1, 0.2, 0.3)
    fees$ppnAssets$tierMethod <- "wholeFund"

    assetValue = c(100, 100)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(10, 10)
    expect_equal(result, expected)

    assetValue = c(100.1, 100.1)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(20.02, 20.02)
    expect_equal(result, expected)

    assetValue = c(250, 250)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(50, 50)
    expect_equal(result, expected)

    assetValue = c(300, 300)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(90, 90)
    expect_equal(result, expected)


    #three tiers, banded method, no increases
    fees$ppnAssets$tierFloor <- c(0, 100, 250)
    fees$ppnAssets$tierFeePpn <- c(0.1, 0.2, 0.3)
    fees$ppnAssets$tierMethod <- "banded"

    assetValue = c(100, 100)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(10, 10)
    expect_equal(result, expected)

    assetValue = c(150, 150)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(100 * 0.1 + 50 * 0.2, 100 * 0.1 + 50 * 0.2)
    expect_equal(result, expected)

    assetValue = c(300, 300)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(100 * 0.1 + 150 * 0.2 + 50 * 0.3, 100 * 0.1 + 150 * 0.2 + 50 * 0.3)
    expect_equal(result, expected)



    #three tiers, wholefund method, RPI increases
    fees$ppnAssets$tierFloor <- c(0, 100, 250)
    fees$ppnAssets$tierFeePpn <- c(0.1, 0.2, 0.3)
    fees$ppnAssets$tierMethod <- "wholeFund"
    fees$ppnAssets$tierFloorIncrease <- platformIncrease_rpi

    feeFormulae <-  f(fees, testEssData, 1:4)



    assetValue = c(100 * 1.03, 100 * 1.01)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(0.1 * 100 * 1.03, 0.1 * 100 * 1.01)
    expect_equal(result, expected)

    assetValue = c(100 * 1.03 + 1, 100 * 1.01 + 1)
    projIndex = 2
    result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    expected = c(0.2 * 100 * 1.03, 0.2 * 100 * 1.01)
    expect_equal(result, expected)

    # assetValue = c(100.1, 100.1)
    # projIndex = 2
    # result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    # expected = c(20.02, 20.02)
    # expect_equal(result, expected)
    #
    # assetValue = c(250, 250)
    # projIndex = 2
    # result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    # expected = c(50, 50)
    # expect_equal(result, expected)
    #
    # assetValue = c(300, 300)
    # projIndex = 2
    # result = f(fees, testEssData, 1:4)$tierFn(assetValue, projIndex)
    # expected = c(90, 90)
    # expect_equal(result, expected)



  }
)
