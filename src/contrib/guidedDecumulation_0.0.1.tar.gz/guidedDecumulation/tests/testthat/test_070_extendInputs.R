library(guidedDecumulation)
context("Extend inputs")

test_that(
  "extendInput has length nproj + 1", {

    nproj <- 5
    #create simpler fn name for use in tests
    f <- function(x) {
      guidedDecumulation:::extendInputsForProjectionPeriod(x, nproj)
    }
    input_1 <- 0.5
    input_2 <- c(0.5, 0.6)
    input_3 <- c(0.5, 0.6, 0.7, 0.8, 0.9)

    #check lengths are all the same
    expect_length(f(input_1), nproj + 1)
    expect_length(f(input_2), nproj + 1)
    expect_length(f(input_3), nproj + 1)

  })

test_that(
  "extendInput starts with 0", {
    nproj <- 5
    #create simpler fn name for use in tests
    f <- function(x) {
      head(guidedDecumulation:::extendInputsForProjectionPeriod(x, nproj), 1)
    }
    input_1 <- 0.5
    input_2 <- c(0.5, 0.6)
    input_3 <- c(0.5, 0.6, 0.7, 0.8, 0.9)

    expect_equal(f(input_1), 0)
    expect_equal(f(input_2), 0)
    expect_equal(f(input_3), 0)
  }
)

test_that(
  "extendInput applied correctly", {
    nproj <- 5
    #create simpler fn name for use in tests
    f <- function(x) {
      guidedDecumulation:::extendInputsForProjectionPeriod(x, nproj)
    }
    input_1 <- 0.5
    input_2 <- c(0.5, 0.6)
    input_3 <- c(0.5, 0.6, 0.7, 0.8, 0.9)
    output_1 <- c(0, 0.5, 0.5, 0.5, 0.5, 0.5)
    output_2 <- c(0, 0.5, 0.6, 0.6, 0.6, 0.6)
    output_3 <- c(0, 0.5, 0.6, 0.7, 0.8, 0.9)

    expect_equal(f(input_1), output_1)
    expect_equal(f(input_2), output_2)
    expect_equal(f(input_3), output_3)
  }
)


test_that(
  "extendInput cuts short appropriately", {
    nproj <- 3
    #create simpler fn name for use in tests
    f <- function(x) {
      guidedDecumulation:::extendInputsForProjectionPeriod(x, nproj)
    }
    input_1 <- c(0.5, 0.6, 0.7, 0.8, 0.9)
    output_1 <- c(0, 0.5, 0.6, 0.7)

    expect_equal(f(input_1), output_1)
  }
)

test_that(
  "extendInput fails on wrong inputs", {

    f <- function(x, y) {
      guidedDecumulation:::extendInputsForProjectionPeriod(x, y)
    }
    nproj <- 5
    nproj_1 <- c(4, 5)
    nproj_2 <- "a"
    input_1 <- c(1, 2, 3)
    input_2 <- "a"

    expect_error(f(input_1, nproj_1))
    expect_error(f(input_2, nproj))
    expect_error(f(input_1, nproj_2))
    expect_error(f(input_2, nproj))
  }
)


