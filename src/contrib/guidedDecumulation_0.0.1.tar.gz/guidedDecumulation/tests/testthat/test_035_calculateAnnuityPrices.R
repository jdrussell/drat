library(guidedDecumulation)
context("Calculate annuity prices")


survivalProbs <-
  data.frame(
    age = c(65, 66, 67, 68, 69, 70),
    survivalProbs = c(1, 0.99, 0.97, 0.94, 0.9, 0)
    )

increaseData <-
  list(
    increaseType = "rpi",
    increaseRate = 0.0
  )


essData <- list(
  economicData  = list(
    corpSpread_AA = matrix(c(0.01, 0.02, 0.03, 0.04, 0.05, 0.06,
                             0.07, 0.08, 0.09, 0.10, 0.11, 0.12),
                             nrow = 6, ncol = 2),
    giltsRealYield = matrix(c(0.02, 0.03, 0.04, 0.05, 0.06, 0.07,
                              0.08, 0.09, 0.10, 0.11, 0.12, 0.13),
                              nrow = 6, ncol = 2),
    giltsNominalYield = matrix(c(0.04, 0.05, 0.06, 0.07, 0.08, 0.09,
                                 0.10, 0.11, 0.12, 0.13, 0.14, 0.15),
                                 nrow = 6, ncol = 2)
  )
)

f <- function(maxAge, survivalProbs, increaseData, essData) {
  guidedDecumulation:::calculateAnnuityPrices(
    maxAge, survivalProbs, increaseData, essData
  )
}


test_that(
  "returns a correctly structured matrix", {

    maxAge <- 67
    output <- f(maxAge, survivalProbs, increaseData, essData)

    expect_true(is.matrix(output))
    expect_true(dim(output)[1] == (67 - 65 + 1))
    expect_true(dim(output)[2] == ncol(essData$economicData$giltsRealYield))

    maxAge <- 69
    output <- f(maxAge, survivalProbs, increaseData, essData)

    expect_true(dim(output)[1] == (69 - 65 + 1))

  }
)


test_that(
  "returns correct values for RPI linked annuity", {

    annuityYield <-
      essData$economicData$giltsRealYield + essData$economicData$corpSpread_AA

    #check result for a single horizon and sim the long way
    maxAge <- 67
    output <- f(maxAge, survivalProbs, increaseData, essData)

    yr1sim1 <-
      1 * (survivalProbs$survivalProbs[2] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ 0 +
      1 * (survivalProbs$survivalProbs[3] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -1 +
      1 * (survivalProbs$survivalProbs[4] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -2 +
      1 * (survivalProbs$survivalProbs[5] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -3 +
      1 * (survivalProbs$survivalProbs[6] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -4

    expected <- yr1sim1
    expect_equal(output[2], expected)

    #check that if target age is the last age before death, that the annuity value is 1
    maxAge <- 69
    output <- f(maxAge, survivalProbs, increaseData, essData)

    expect_equal(tail(output[,1], 1), 1)

    #now check the rest more efficiently
    expected <-
      do.call(
        rbind,
        purrr::map(seq(1:(maxAge - 65 + 1)), function(i) {
          wtdPayments <-
            if (i == 1) {
              survivalProbs$survivalProbs
            } else {
              tail(survivalProbs$survivalProbs, -i + 1) /
                survivalProbs$survivalProbs[i]
            }
          purrr::reduce(
            purrr::map(
              1:length(wtdPayments),
              ~ wtdPayments[.x] * ((1 + annuityYield[i, ]) ^ (-.x + 1))
            ), `+`)
        })
      )

    expect_equal(output, expected)

  }
)


test_that(
  "returns correct values for flat annuity", {

    increaseData$increaseType = "none"

    annuityYield <-
      essData$economicData$giltsNominalYield +
      essData$economicData$corpSpread_AA

    #check result for a single horizon and sim the long way
    maxAge <- 67
    output <- f(maxAge, survivalProbs, increaseData, essData)

    yr1sim1 <-
      1 * (survivalProbs$survivalProbs[2] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ 0 +
      1 * (survivalProbs$survivalProbs[3] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -1 +
      1 * (survivalProbs$survivalProbs[4] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -2 +
      1 * (survivalProbs$survivalProbs[5] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -3 +
      1 * (survivalProbs$survivalProbs[6] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYield[2, 1]) ^ -4

    expected <- yr1sim1
    expect_equal(output[2], expected)

    #check that if target age is the last age before death, that the annuity value is 1
    maxAge <- 69
    output <- f(maxAge, survivalProbs, increaseData, essData)

    expect_equal(tail(output[,1], 1), 1)

    #now check the rest more efficiently
    expected <-
      do.call(
        rbind,
        purrr::map(seq(1:(maxAge - 65 + 1)), function(i) {
          wtdPayments <-
            if (i == 1) {
              survivalProbs$survivalProbs
            } else {
              tail(survivalProbs$survivalProbs, -i + 1) /
                survivalProbs$survivalProbs[i]
            }
          purrr::reduce(
            purrr::map(
              1:length(wtdPayments),
              ~ wtdPayments[.x] * ((1 + annuityYield[i, ]) ^ (-.x + 1))
            ), `+`)
        })
      )

    expect_equal(output, expected)

  }
)


test_that(
  "returns correct values for fixed increase annuity", {

    #annuity prices for fixed and 0% increase rate should be the same
    increaseData$increaseType = "none"
    maxAge <- 69
    outputNone <- f(maxAge, survivalProbs, increaseData, essData)

    increaseData$increaseType = "fixed"
    increaseData$increaseRate = 0
    maxAge <- 69
    outputFixedZero <- f(maxAge, survivalProbs, increaseData, essData)

    expect_equal(outputNone, outputFixedZero)

    #now test for non-zero fixed increases
    increaseData$increaseType = "fixed"
    increaseData$increaseRate = 0.03

    annuityYield <-
      essData$economicData$giltsNominalYield +
      essData$economicData$corpSpread_AA

    annuityYieldAdjusted <-
      (1 + essData$economicData$giltsNominalYield +
          essData$economicData$corpSpread_AA) /
      (1 + increaseData$increaseRate) - 1


    #check result for a single horizon and sim the long way
    maxAge <- 67
    output <- f(maxAge, survivalProbs, increaseData, essData)

    yr1sim1 <-
      1 * (survivalProbs$survivalProbs[2] /
          survivalProbs$survivalProbs[2]) * (1 + annuityYield[2, 1]) ^ 0 +
      1.03 * (survivalProbs$survivalProbs[3] /
          survivalProbs$survivalProbs[2]) * (1 + annuityYield[2, 1]) ^ -1 +
      1.03 * 1.03 * (survivalProbs$survivalProbs[4] /
          survivalProbs$survivalProbs[2]) * (1 + annuityYield[2, 1]) ^ -2 +
      1.03 * 1.03 * 1.03 * (survivalProbs$survivalProbs[5] /
          survivalProbs$survivalProbs[2]) * (1 + annuityYield[2, 1]) ^ -3 +
      1.03 * 1.03 * 1.03 * 1.03 * (survivalProbs$survivalProbs[6] /
          survivalProbs$survivalProbs[2]) * (1 + annuityYield[2, 1]) ^ -4

    yr1sim1Alt <-
      1 * (survivalProbs$survivalProbs[2] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYieldAdjusted[2, 1]) ^ 0 +
      1 * (survivalProbs$survivalProbs[3] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYieldAdjusted[2, 1]) ^ -1 +
      1 * (survivalProbs$survivalProbs[4] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYieldAdjusted[2, 1]) ^ -2 +
      1 * (survivalProbs$survivalProbs[5] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYieldAdjusted[2, 1]) ^ -3 +
      1 * (survivalProbs$survivalProbs[6] / survivalProbs$survivalProbs[2]) *
      (1 + annuityYieldAdjusted[2, 1]) ^ -4

    expect_equal(output[2], yr1sim1)
    expect_equal(output[2], yr1sim1Alt)

    #check that if target age is the last age before death, that the annuity value is 1
    maxAge <- 69
    output <- f(maxAge, survivalProbs, increaseData, essData)

    expect_equal(tail(output[,1], 1), 1)

    #now check the rest more efficiently
    expected <-
      do.call(
        rbind,
        purrr::map(seq(1:(maxAge - 65 + 1)), function(i) {
          wtdPayments <-
            if (i == 1) {
              survivalProbs$survivalProbs
            } else {
              tail(survivalProbs$survivalProbs, -i + 1) /
                survivalProbs$survivalProbs[i]
            }
          purrr::reduce(
            purrr::map(
              1:length(wtdPayments),
              ~ wtdPayments[.x] * ((1 + annuityYieldAdjusted[i, ]) ^ (-.x + 1))
            ), `+`)
        })
      )

    expect_equal(output, expected)

  }
)
