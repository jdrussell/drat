library(guidedDecumulation)
context("Vector Matrix Calc")

test_that(
  "always returns matrix", {

    #create simpler fn name for use in tests
    f <- function(v, m) {
      guidedDecumulation:::applyVectorMatrixCalc(v, m)
    }

    v <- c(1, 2, 3)
    m_1 <- matrix(1, nrow = 5, ncol = 1)
    m_2 <- matrix(1, nrow = 5, ncol = 3)

    expect_true(is.matrix(f(v, m_1)))
    expect_true(is.matrix(f(v, m_2)))
  }
)

test_that(
  "row subsetting ok", {

    #create simpler fn name for use in tests
    f <- function(v, m) {
      guidedDecumulation:::applyVectorMatrixCalc(v, m)
    }

    v <- c(1, 2, 3)
    m_1 <- matrix(1, nrow = 2, ncol = 1)
    m_2 <- matrix(1:5, nrow = 5, ncol = 1)
    m_2_out <- matrix(c(1, 4, 9), nrow = 3, ncol = 1)

    expect_error(f(v, m_1))
    expect_equal(f(v, m_2), m_2_out)
  }
)

test_that(
  "matrix multiplication correct", {

    #create simpler fn name for use in tests
    f <- function(v, m) {
      guidedDecumulation:::applyVectorMatrixCalc(v, m)
    }

    v <- c(10, 11, 12)
    m <- matrix(c(1, 2, 3, 7, 8, 9), nrow = 3, ncol = 2)
    m_out <-
      matrix(c(10, 22, 36, 70, 88, 108), nrow = 3, ncol = 2)

    expect_equal(f(v, m), m_out)
  }
)
