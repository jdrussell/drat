library(guidedDecumulation)
context("Apply increase")

testEssData <-
  list(
    economicData =
      list(
        rpiActualIndex =
          matrix(
            c(1, 1.03, 1.03 * 1.04, 1.03 * 1.04 * 1.05,
              1, 1.01, 1.01 * 1.02, 1.01 * 1.02 * 1.03),
            nrow = 4, ncol = 2
          )
      )
    )
nRows <- nrow(testEssData$economicData$rpiActualIndex)
nCols <- ncol(testEssData$economicData$rpiActualIndex)
increaseDataBase <-
  list(
    increaseType = "none",
    increaseRate = NA
  )

test_that(
  "all increase types return matrices", {

    f <- function(x, y, essData) {
      guidedDecumulation:::applyIncrease(x, y, essData)
    }
    x_1 <- 100
    x_2 <- rep.int(100, nRows)
    y_none <- increaseDataBase
    y_none$increaseType <- "none"
    y_rpi <- increaseDataBase
    y_rpi$increaseType <- "rpi"
    y_fixed <- increaseDataBase
    y_fixed$increaseType <- "fixed"
    y_salary <- increaseDataBase
    y_salary$increaseType <- "rpi"
    y_salary$increaseRate <- rep.int(0.01, nRows)

    expect_true(is.matrix(f(x_1, y_none, testEssData)))
    expect_true(is.matrix(f(x_1, y_rpi, testEssData)))
    expect_true(is.matrix(f(x_1, y_fixed, testEssData)))
    expect_true(is.matrix(f(x_1, y_salary, testEssData)))
    expect_true(is.matrix(f(x_2, y_none, testEssData)))
    expect_true(is.matrix(f(x_2, y_rpi, testEssData)))
    expect_true(is.matrix(f(x_2, y_fixed, testEssData)))
    expect_true(is.matrix(f(x_2, y_salary, testEssData)))
  }
)

test_that(
  "fixed rate applied correctly for default type (flow)", {

    f <- function(x, y, essData) {
      guidedDecumulation:::applyIncrease(x, y, essData)
    }
    x <- c(0, rep.int(100, nRows - 1))
    y_fixed <- increaseDataBase
    y_fixed$increaseType <- "fixed"
    y_fixed$increaseRate <- c(0, rep.int(0.04, nRows - 1))
    y_fixed_output <-
      diag(c(0, 100, 100 * 1.04, 100 * 1.04 ^ 2)) %*%
      matrix(1, nrow = nRows, ncol = nCols)
    expect_equal(f(x, y_fixed, testEssData), y_fixed_output)
  }
)

test_that(
  "fixed rate applied correctly for stock type", {

    stockOrFlow = "stock"
    f <- function(x, y, essData, nproj, stockOrFlow) {
      guidedDecumulation:::applyIncrease(x, y, essData, stockOrFlow)
    }
    x <- c(0, rep.int(100, nRows - 1))
    y_fixed <- increaseDataBase
    y_fixed$increaseType <- "fixed"
    y_fixed$increaseRate <- c(0, rep.int(0.04, nRows - 1))
    y_fixed_output <-
      diag(c(0, 100 * 1.04, 100 * 1.04 ^ 2, 100 * 1.04 ^ 3)) %*%
      matrix(1, nrow = nRows, ncol = nCols)
    expect_equal(f(x, y_fixed, testEssData, nproj, stockOrFlow), y_fixed_output)
  }
)

test_that(
  "RPI applied correctly for default type (flow)", {

    f <- function(x, y, essData) {
      guidedDecumulation:::applyIncrease(x, y, essData)
    }
    x <- c(0, rep.int(100, nRows - 1))
    y_rpi <- increaseDataBase
    y_rpi$increaseType <- "rpi"
    y_rpi$increaseRate <- c(0, rep.int(0, nRows - 1))
    y_rpi_output <-
      matrix(
        c(0, 100, 100 * 1.03, 100 * 1.03 * 1.04,
          0, 100, 100 * 1.01, 100 * 1.01 * 1.02),
        nrow = 4, ncol = 2
      )
    expect_equal(f(x, y_rpi, testEssData), y_rpi_output)
  }
)

test_that(
  "RPI applied correctly for stock type", {

    stockOrFlow = "stock"
    f <- function(x, y, essData, stockOrFlow) {
      guidedDecumulation:::applyIncrease(x, y, essData, stockOrFlow)
    }
    x <- c(0, rep.int(100, nRows - 1))
    y_rpi <- increaseDataBase
    y_rpi$increaseType <- "rpi"
    y_rpi$increaseRate <- c(0, rep.int(0, nRows - 1))
    y_rpi_output <-
      matrix(
        c(0, 100 * 1.03, 100 * 1.03 * 1.04, 100 * 1.03 * 1.04 * 1.05,
          0, 100 * 1.01, 100 * 1.01 * 1.02, 100 * 1.01 * 1.02 * 1.03),
        nrow = 4, ncol = 2
      )
    expect_equal(f(x, y_rpi, testEssData, stockOrFlow), y_rpi_output)
  }
)

test_that(
  "none applied correctly for default type (flow)", {

    nproj = nrow(testEssData$economicData$rpiActualIndex) - 1
    f <- function(x, y, essData) {
      guidedDecumulation:::applyIncrease(x, y, essData)
    }
    x <- c(0, rep.int(100, nRows - 1))
    y_none <- increaseDataBase
    y_none$increaseType <- "none"
    y_none$increaseRate <- c(0, rep.int(0, nRows - 1))
    y_none_output <-
      diag(c(0, 100, 100, 100)) %*%
      matrix(1, nrow = nRows, ncol = nCols)
    expect_equal(f(x, y_none, testEssData), y_none_output)
  }
)

test_that(
  "none applied correctly for stock type", {

    stockOrFlow = "stock"
    f <- function(x, y, essData, stockOrFlow) {
      guidedDecumulation:::applyIncrease(x, y, essData, stockOrFlow)
    }
    x <- c(0, rep.int(100, nRows - 1))
    y_none <- increaseDataBase
    y_none$increaseType <- "none"
    y_none$increaseRate <- c(0, rep.int(0, nRows - 1))
    y_none_output <-
      diag(c(0, 100, 100 , 100)) %*%
      matrix(1, nrow = nRows, ncol = nCols)
    expect_equal(f(x, y_none, testEssData, stockOrFlow), y_none_output)
  }
)

test_that(
  "RPI deflation applied correctly to a matrix with multiple columns for default type (flow)", {

    f <- function(output, essData) {
      guidedDecumulation:::transformToReal(output, essData)
    }

    output <- matrix(
      c(0, 100, 100 * 1.03, 100 * 1.03 * 1.04,
        0, 100, 100 * 1.01, 100 * 1.01 * 1.02),
      nrow = 4, ncol = 2
    )

    realOutput <-
      matrix(
        c(0, 100, 100, 100,
          0, 100, 100, 100),
        nrow = 4, ncol = 2
      )
    expect_equal(f(output, testEssData), realOutput)
  }
)


test_that(
  "RPI deflation applied correctly to a matrix with multiple columns for stock type", {

    stockOrFlow = "stock"

    f <- function(output, essData, stockOrFlow) {
      guidedDecumulation:::transformToReal(output, essData, stockOrFlow)
    }

    output <- matrix(
      c(0, 100 * 1.03, 100 * 1.03 * 1.04, 100 * 1.03 * 1.04 * 1.05,
        0, 100 * 1.01, 100 * 1.01 * 1.02, 100 * 1.01 * 1.02 * 1.03),
      nrow = 4, ncol = 2
    )

    realOutput <-
      matrix(
        c(0, 100, 100, 100,
          0, 100, 100, 100),
        nrow = 4, ncol = 2
      )
    expect_equal(f(output, testEssData, stockOrFlow), realOutput)
  }
)


test_that(
  "RPI deflation applied correctly to a matrix with one column for default type (flow)", {

    f <- function(output, essData) {
      guidedDecumulation:::transformToReal(output, essData)
    }

    output <- matrix(
      c(0, 100, 100 * 1.03, 100 * 1.03 * 1.04
        ),
      nrow = 4, ncol = 1
    )

    realOutput <-
      matrix(
        c(0, 100, 100, 100,
          0, 100, 100 * 1.03 / 1.01, 100 * 1.03 * 1.04 / (1.01 * 1.02)),
        nrow = 4, ncol = 2
      )
    expect_equal(f(output, testEssData), realOutput)
  }
)

test_that(
  "RPI deflation applied correctly to a matrix with one column for stock type", {

    stockOrFlow = "stock"

    f <- function(output, essData, stockOrFlow) {
      guidedDecumulation:::transformToReal(output, essData, stockOrFlow)
    }

    output <- matrix(
      c(0, 100 * 1.03, 100 * 1.03 * 1.04, 100 * 1.03 * 1.04 * 1.05
      ),
      nrow = 4, ncol = 1
    )

    realOutput <-
      matrix(
        c(0, 100, 100, 100,
          0, 100 * 1.03 / 1.01,
          100 * 1.03 * 1.04 / (1.01 * 1.02),
          100 * 1.03 * 1.04 * 1.05 / (1.01 * 1.02 * 1.03)),
        nrow = 4, ncol = 2
      )
    expect_equal(f(output, testEssData, stockOrFlow), realOutput)
  }
)

test_that(
  "RPI deflation applied correctly to a vector for default type (flow)", {

    f <- function(output, essData) {
      guidedDecumulation:::transformToReal(output, essData)
    }

    output <- c(0, 100, 100 * 1.03, 100 * 1.03 * 1.04)

    realOutput <-
      matrix(
        c(0, 100, 100, 100,
          0, 100, 100 * 1.03 / 1.01, 100 * 1.03 * 1.04 / (1.01 * 1.02)),
        nrow = 4, ncol = 2
      )
    expect_equal(f(output, testEssData), realOutput)
  }
)

test_that(
  "RPI deflation applied correctly to a vector for stock type", {

    stockOrFlow = "stock"

    f <- function(output, essData, stockOrFlow) {
      guidedDecumulation:::transformToReal(output, essData, stockOrFlow)
    }

    output <- c(0, 100 * 1.03, 100 * 1.03 * 1.04, 100 * 1.03 * 1.04 * 1.05)


    realOutput <-
      matrix(
        c(0, 100, 100, 100,
          0, 100 * 1.03 / 1.01,
          100 * 1.03 * 1.04 / (1.01 * 1.02),
          100 * 1.03 * 1.04 * 1.05 / (1.01 * 1.02 * 1.03)),
        nrow = 4, ncol = 2
      )
    expect_equal(f(output, testEssData, stockOrFlow), realOutput)
  }
)
