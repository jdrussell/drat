library(guidedDecumulation)
context("Calculate survival probs")



memberQxTable <-
    data.frame(
      Age = c(65, 66, 67, 68, 69),
      Qx = c(0.01, 0.02, 0.03, 0.04, 1)
)


f <- function(memberQxTable) {
  guidedDecumulation:::calculateSurvivalProbs(memberQxTable)
}

validOutputNames <- c("age", "survivalProbs", "deathAtAge")

output <- f(memberQxTable)



test_that(
  "returns a correctly structured data frame", {
    expect_true(is.data.frame(output))
    expect_true(all(names(output) %in% validOutputNames))
    expect_true(all(validOutputNames %in% names(output)))
    expect_true(is.vector(output$age))
    expect_true(is.vector(output$survivalProbs))
    expect_true(is.vector(output$deathAtAge))
    expect_true(length(output$age) == length(output$survivalProbs))
    expect_true(length(output$age) == length(output$deathAtAge))
  }
)


test_that(
  "returns correct ages", {

    expected <- c(65, 66, 67, 68, 69)

    expect_equal(output$age, expected)

  }
)

test_that(
  "returns correct survival probs", {

    expected <-
      c(
        1,
        1 - 0.01,
        (1 - 0.01) * (1 - 0.02),
        (1 - 0.01) * (1 - 0.02) * (1 - 0.03),
        (1 - 0.01) * (1 - 0.02) * (1 - 0.03) * (1 - 0.04)
      )

    expect_equal(output$survivalProbs, expected)

  }
)

test_that(
  "returns correct probability of death at age", {

    expected <-
      c(
        1 * 0.01,
        (1 - 0.01) * 0.02,
        ((1 - 0.01) * (1 - 0.02)) * 0.03,
        ((1 - 0.01) * (1 - 0.02) * (1 - 0.03)) * 0.04,
        ((1 - 0.01) * (1 - 0.02) * (1 - 0.03) * (1 - 0.04)) * 1
      )

    expect_equal(output$deathAtAge, expected)

  }
)
