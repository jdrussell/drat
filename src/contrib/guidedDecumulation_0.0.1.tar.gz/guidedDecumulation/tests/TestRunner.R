tryCatch({
    args <- commandArgs(trailingOnly = TRUE)
    testsPath <<- args[1]
    packageToTest <<- args[2]

    .libPaths("C:/R")
    library(testthat)
    library(packageToTest, character.only = TRUE)

    message("results", test_dir(testsPath))
}, error = function(e) {
    failureMessage <- c("R unit test run exception: ", as.character(e))
    return(failureMessage)
})
