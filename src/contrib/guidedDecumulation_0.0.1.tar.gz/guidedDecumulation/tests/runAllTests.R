library(testthat)
library(guidedDecumulation)

test_dir(file.path(getwd(),"tests","testthat"))
