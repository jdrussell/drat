library(testthat)
library(guidedDecumulation)

test_check("guidedDecumulation")
