#ifndef dplyr_DataFrameVisitors_set_H
#define dplyr_DataFrameVisitors_set_H

namespace dplyr {

    typedef VisitorSetIndexSet<DataFrameVisitors> DataFrameVisitorsIndexSet ;

}

#endif
